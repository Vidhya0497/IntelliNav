export type MovementAction = "FORWARD" | "TURN_LEFT" | "TURN_RIGHT" | "STOP";
export type MovementStatus = "PENDING" | "EXECUTING" | "COMPLETED" | "FAILED" | "CANCELLED";
export type MovementPoint = [number, number];

export type MovementCommand = {
  step: number;
  action: MovementAction;
  segment?: string;
  status: MovementStatus;
};

export type TimedMovementCommand = MovementCommand & {
  linear_x: number;
  angular_z: number;
  duration: number;
};

export type TimedMovementOptions = {
  forwardSpeed?: number;
  turnSpeed?: number;
  mapUnitsPerMeter?: number;
  minimumForwardDuration?: number;
  turnDuration?: number;
};

const MIN_SEGMENT_LENGTH = 4;
const DEFAULT_TIMED_OPTIONS: Required<TimedMovementOptions> = {
  forwardSpeed: 0.1,
  turnSpeed: 0.6,
  mapUnitsPerMeter: 10,
  minimumForwardDuration: 0.35,
  turnDuration: 0.8,
};

function distance(a: MovementPoint, b: MovementPoint) {
  return Math.hypot(b[0] - a[0], b[1] - a[1]);
}

function segmentName(index: number) {
  return `SEGMENT_${String(index + 1).padStart(2, "0")}`;
}

function routePoints(path: MovementPoint[]) {
  return path.filter((point, index) => index === 0 || distance(path[index - 1], point) >= MIN_SEGMENT_LENGTH);
}

/**
 * Converts the existing screen-space simulation path into the dashboard's
 * movement plan. The path remains the source of truth; this utility never
 * mutates or animates it. Screen-space Y increases downward, so a negative
 * cross product is a left turn.
 */
export function extractMovementCommands(path: MovementPoint[], progress = 0): MovementCommand[] {
  const points = routePoints(path);
  if (points.length < 2) return [{ step: 1, action: "STOP", status: "PENDING" }];

  const commands: MovementCommand[] = [];
  for (let index = 0; index < points.length - 1; index += 1) {
    const current = points[index];
    const next = points[index + 1];
    commands.push({ step: commands.length + 1, action: "FORWARD", segment: segmentName(index), status: "PENDING" });

    if (index < points.length - 2) {
      const following = points[index + 2];
      const firstVector = [next[0] - current[0], next[1] - current[1]];
      const secondVector = [following[0] - next[0], following[1] - next[1]];
      const cross = firstVector[0] * secondVector[1] - firstVector[1] * secondVector[0];
      if (Math.abs(cross) > 0.01) {
        commands.push({ step: commands.length + 1, action: cross < 0 ? "TURN_LEFT" : "TURN_RIGHT", status: "PENDING" });
      }
    }
  }
  commands.push({ step: commands.length + 1, action: "STOP", status: "PENDING" });

  const activeStep = progress >= 1 ? commands.length : Math.min(commands.length - 1, Math.max(0, Math.floor(progress * commands.length)));
  return commands.map((command, index) => ({
    ...command,
    status: index < activeStep ? "COMPLETED" : index === activeStep && activeStep < commands.length - 1 ? "EXECUTING" : "PENDING",
  }));
}

/**
 * Maps each existing warehouse path segment into the timed /move payload the
 * existing robot API accepts. The caller must execute the returned commands
 * serially; no command is sent by this helper.
 */
export function buildTimedMovementCommands(path: MovementPoint[], options: TimedMovementOptions = {}): TimedMovementCommand[] {
  const config = { ...DEFAULT_TIMED_OPTIONS, ...options };
  const points = routePoints(path);
  if (points.length < 2) {
    return [{ step: 1, action: "STOP", status: "PENDING", linear_x: 0, angular_z: 0, duration: 0.1 }];
  }

  const commands: TimedMovementCommand[] = [];
  for (let index = 0; index < points.length - 1; index += 1) {
    const segmentDistanceMeters = distance(points[index], points[index + 1]) / config.mapUnitsPerMeter;
    commands.push({
      step: commands.length + 1,
      action: "FORWARD",
      segment: segmentName(index),
      status: "PENDING",
      linear_x: config.forwardSpeed,
      angular_z: 0,
      duration: Math.max(config.minimumForwardDuration, segmentDistanceMeters / Math.max(config.forwardSpeed, 0.01)),
    });

    if (index < points.length - 2) {
      const current = points[index];
      const next = points[index + 1];
      const following = points[index + 2];
      const firstVector = [next[0] - current[0], next[1] - current[1]];
      const secondVector = [following[0] - next[0], following[1] - next[1]];
      const cross = firstVector[0] * secondVector[1] - firstVector[1] * secondVector[0];
      if (Math.abs(cross) > 0.01) {
        const action = cross < 0 ? "TURN_LEFT" : "TURN_RIGHT";
        commands.push({ step: commands.length + 1, action, status: "PENDING", linear_x: 0, angular_z: action === "TURN_LEFT" ? config.turnSpeed : -config.turnSpeed, duration: config.turnDuration });
      }
    }
  }
  commands.push({ step: commands.length + 1, action: "STOP", status: "PENDING", linear_x: 0, angular_z: 0, duration: 0.1 });
  return commands;
}

export function movementActionLabel(action: MovementAction) {
  return action === "TURN_LEFT" ? "Turn left" : action === "TURN_RIGHT" ? "Turn right" : action === "FORWARD" ? "Forward" : "Stop";
}

export function movementActionSymbol(action: MovementAction) {
  return action === "TURN_LEFT" ? "↶" : action === "TURN_RIGHT" ? "↷" : action === "FORWARD" ? "↑" : "■";
}
