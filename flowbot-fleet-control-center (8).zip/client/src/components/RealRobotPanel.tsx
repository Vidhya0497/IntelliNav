/*
 * FLOWBOT style reminder: real-robot data must be visually distinct from
 * simulation, compact inside the Fleet area, and explicit about connection
 * state, freshness, and safety decisions.
 */
import { useEffect, useMemo, useRef, useState } from "react";
import { Activity, BatteryCharging, Cable, CircleAlert, MapPin, PlugZap, RefreshCw, ShieldCheck, Wifi, XCircle } from "lucide-react";
import { toast } from "sonner";
import { formatRobotApiError, RobotApi, type RobotBatteryResponse, type RobotDistanceResponse, type RobotHandshake, type RobotPositionResponse, type RobotStatusResponse } from "@/services/robotApi";

type ConnectionState = "DISCONNECTED" | "CONNECTING" | "CONNECTED" | "ERROR" | "CONNECTION LOST";
type RealTelemetry = { status: RobotStatusResponse; position: RobotPositionResponse | null; battery: RobotBatteryResponse | null; distance: RobotDistanceResponse };
export type ConnectedRobotSnapshot = { handshake: RobotHandshake; telemetry: RealTelemetry; ip: string; port: number; api: RobotApi };
type RealRobotPanelProps = { onConnected?: (snapshot: ConnectedRobotSnapshot) => void; onDisconnected?: (robotId: string | null) => void };

const TELEMETRY_POLL_MS = 1_500;
const MAX_CONSECUTIVE_FAILURES = 3;

export default function RealRobotPanel({ onConnected, onDisconnected }: RealRobotPanelProps) {
  const [ip, setIp] = useState("");
  const [port, setPort] = useState("");
  const [connectionState, setConnectionState] = useState<ConnectionState>("DISCONNECTED");
  const [handshake, setHandshake] = useState<RobotHandshake | null>(null);
  const [telemetry, setTelemetry] = useState<RealTelemetry | null>(null);
  const [errorMessage, setErrorMessage] = useState("");
  const [lastSuccess, setLastSuccess] = useState<string | null>(null);
  const [consumptionPerMeter, setConsumptionPerMeter] = useState(0.5);
  const [safetyReserve, setSafetyReserve] = useState(10);
  const apiRef = useRef<RobotApi | null>(null);
  const failuresRef = useRef(0);

  const updateTelemetry = async (api: RobotApi, connectedRobotId?: string): Promise<RealTelemetry> => {
    const [status, distance] = await Promise.all([api.getStatus(), api.getDistanceToTarget()]);
    let position: RobotPositionResponse | null = null;
    try {
      position = await api.getPosition();
    } catch {
      // A connected robot may expose status before its localization source is ready.
      position = null;
    }
    let battery: RobotBatteryResponse | null = null;
    try {
      battery = await api.getBattery();
    } catch (error) {
      if (!(error instanceof Error) || !error.message.includes("No BatteryState received")) throw error;
    }
    const expectedId = connectedRobotId ?? handshake?.robot_id;
    if (expectedId && [status.robot_id, ...(battery ? [battery.robot_id] : []), distance.robot_id].some((robotId) => robotId !== expectedId)) {
      throw new Error("Robot API responses refer to different robot IDs.");
    }
    setTelemetry({ status, position, battery, distance });
    if (handshake) onConnected?.({ handshake, telemetry: { status, position, battery, distance }, ip, port: Number(port), api });
    const stamp = new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" });
    setLastSuccess(stamp);
    failuresRef.current = 0;
    return { status, position, battery, distance };
  };

  const connect = async () => {
    setConnectionState("CONNECTING");
    setErrorMessage("");
    setTelemetry(null);
    setHandshake(null);
    failuresRef.current = 0;
    try {
      const api = new RobotApi(ip, Number(port));
      const nextHandshake = await api.connectRobot();
      const nextTelemetry = await updateTelemetry(api, nextHandshake.robot_id);
      apiRef.current = api;
      setHandshake(nextHandshake);
      onConnected?.({ handshake: nextHandshake, telemetry: nextTelemetry, ip: ip.trim(), port: Number(port), api });
      setConnectionState("CONNECTED");
      toast.success("Real robot connected", { description: `${nextHandshake.robot_id} handshake and telemetry checks succeeded.` });
    } catch (error) {
      apiRef.current = null;
      setConnectionState("ERROR");
      setErrorMessage(formatRobotApiError(error));
    }
  };

  const disconnect = () => {
    onDisconnected?.(handshake?.robot_id ?? null);
    apiRef.current = null;
    failuresRef.current = 0;
    setConnectionState("DISCONNECTED");
    setHandshake(null);
    setTelemetry(null);
    setErrorMessage("");
    toast.info("Real robot disconnected", { description: "Telemetry polling has stopped." });
  };

  useEffect(() => {
    if (connectionState !== "CONNECTED" || !apiRef.current) return;
    const poll = async () => {
      const api = apiRef.current;
      if (!api) return;
      try {
        await updateTelemetry(api);
      } catch (error) {
        failuresRef.current += 1;
        if (failuresRef.current >= MAX_CONSECUTIVE_FAILURES) {
          apiRef.current = null;
          setTelemetry(null);
          setConnectionState("CONNECTION LOST");
          setErrorMessage(`${formatRobotApiError(error)} Last data received: ${lastSuccess ?? "not available"}.`);
        }
      }
    };
    const timer = window.setInterval(poll, TELEMETRY_POLL_MS);
    return () => window.clearInterval(timer);
  }, [connectionState, lastSuccess]);

  const reachability = useMemo(() => {
    if (!telemetry?.battery) return null;
    const battery = telemetry.battery.battery;
    const distance = telemetry.distance.distance_to_target;
    const travelConsumption = distance * consumptionPerMeter;
    const requiredBattery = travelConsumption + safetyReserve;
    return { battery, distance, travelConsumption, requiredBattery, reachable: battery >= requiredBattery };
  }, [consumptionPerMeter, safetyReserve, telemetry]);

  const statusTone = connectionState === "CONNECTED" ? "healthy" : connectionState === "CONNECTING" ? "pending" : connectionState === "DISCONNECTED" ? "neutral" : "danger";
  const isBusy = connectionState === "CONNECTING";

  return <section className="real-robot-module">
    <div className="real-robot-module-heading"><div><span className="eyebrow orange-text">REAL ROBOT / FLEET BRIDGE</span><h2>Connect an AMR</h2><p>Use the robot-side Python REST API without mixing live telemetry into the simulation.</p></div><span className={`real-state-pill ${statusTone}`}><i />{connectionState}</span></div>
    <div className="real-robot-grid">
      <section className="card real-connection-card">
        <div className="card-heading"><div><span className="eyebrow">ROBOT CONNECTION</span><h3>Endpoint & handshake</h3></div><Cable size={17} className="muted-icon" /></div>
        <div className="real-form-grid"><label><span>IP address</span><input value={ip} onChange={(event) => setIp(event.target.value)} placeholder="192.168.x.x" inputMode="url" disabled={isBusy} /></label><label><span>API port</span><input value={port} onChange={(event) => setPort(event.target.value.replace(/[^0-9]/g, ""))} placeholder="8000" inputMode="numeric" disabled={isBusy} /></label></div>
        <div className="real-action-row"><button className="button button-primary" onClick={connect} disabled={isBusy || !ip.trim() || !port}><PlugZap size={15} />{isBusy ? "Connecting…" : "Connect"}</button><button className="button button-quiet" onClick={disconnect} disabled={connectionState === "DISCONNECTED" || isBusy}><XCircle size={15} />Disconnect</button></div>
        {connectionState === "DISCONNECTED" && <p className="real-help"><Wifi size={13} /> Enter the reachable address of the AMR API. No robot address is stored in the app.</p>}
        {(connectionState === "ERROR" || connectionState === "CONNECTION LOST") && <div className="real-error"><CircleAlert size={15} /><div><strong>{connectionState === "CONNECTION LOST" ? "Robot connection lost" : "Connection failed"}</strong><span>{errorMessage}</span></div></div>}
        {handshake && <div className="handshake-details"><div><span>Robot ID</span><strong>{handshake.robot_id}</strong></div><div><span>Robot type</span><strong>{handshake.robot_type}</strong></div><div><span>API version</span><strong>{handshake.api_version}</strong></div><div><span>Robot endpoint</span><strong>{ip}:{port}</strong></div></div>}
      </section>
      <section className="card real-telemetry-card"><div className="card-heading"><div><span className="eyebrow">REAL ROBOT TELEMETRY</span><h3>{handshake?.robot_id ?? "Waiting for handshake"}</h3></div><button className="icon-button" onClick={() => apiRef.current && updateTelemetry(apiRef.current).catch(() => undefined)} disabled={connectionState !== "CONNECTED"} aria-label="Refresh real robot telemetry"><RefreshCw size={15} /></button></div>{telemetry && handshake ? <><div className="real-telemetry-status"><span className="real-live-dot" /> LIVE DATA · updated {lastSuccess}{telemetry.position ? " · position live" : " · staging location"}</div><div className="real-telemetry-metrics"><div><BatteryCharging size={16} /><span>Battery</span><strong>{telemetry.battery ? `${Math.round(telemetry.battery.battery)}%` : "UNAVAILABLE"}</strong></div><div><MapPin size={16} /><span>Distance to target</span><strong>{telemetry.distance.distance_to_target.toFixed(1)} {telemetry.distance.unit}</strong></div><div><Activity size={16} /><span>Status</span><strong>{telemetry.status.status.toUpperCase()}</strong></div><div><MapPin size={16} /><span>Position</span><strong>X {telemetry.position ? telemetry.position.x.toFixed(1) : "—"} · Y {telemetry.position ? telemetry.position.y.toFixed(1) : "—"}</strong></div></div><div className="real-telemetry-footer"><span>Current task</span><strong>{telemetry.status.current_task ?? "NONE"}</strong></div></> : <div className="real-empty"><ShieldCheck size={18} /><span>Connect a robot to view live battery, distance, status, task, and position data.</span></div>}</section>
    </div>
    <section className="card reachability-card"><div className="card-heading"><div><span className="eyebrow">TARGET REACHABILITY</span><h3>Battery safety decision</h3></div><ShieldCheck size={17} className="muted-icon" /></div><div className="reachability-controls"><label><span>Battery consumption / meter</span><div><input type="number" min="0" step="0.1" value={consumptionPerMeter} onChange={(event) => setConsumptionPerMeter(Number(event.target.value))} /><b>% / m</b></div></label><label><span>Safety reserve</span><div><input type="number" min="0" max="100" step="1" value={safetyReserve} onChange={(event) => setSafetyReserve(Number(event.target.value))} /><b>%</b></div></label></div>{reachability ? <><div className="reachability-calculation"><div><span>Current battery</span><strong>{reachability.battery.toFixed(1)}%</strong></div><div><span>Distance</span><strong>{reachability.distance.toFixed(1)} m</strong></div><div><span>Travel consumption</span><strong>{reachability.travelConsumption.toFixed(1)}%</strong></div><div><span>Required battery</span><strong>{reachability.requiredBattery.toFixed(1)}%</strong></div></div><div className={`reachability-decision ${reachability.reachable ? "reachable" : "unreachable"}`}><div>{reachability.reachable ? <ShieldCheck size={18} /> : <CircleAlert size={18} />}<div><strong>{reachability.reachable ? "TARGET REACHABLE" : "TARGET NOT REACHABLE"}</strong><span>{reachability.reachable ? "The robot has sufficient estimated battery to reach the target." : "Insufficient battery to safely reach target. Select another robot or send this robot to charging."}</span></div></div>{reachability.reachable && <button className="button button-quiet" onClick={() => toast.info("Use Task Allocation to dispatch the mapped route.", { description: "Reachability is confirmed; the selected task flow will send serial /move commands and finish with /stop." })}>Assign task</button>}</div></> : <div className="real-empty"><ShieldCheck size={18} /><span>{telemetry && !telemetry.battery ? "Live telemetry connected, but this myAGV ROS image provides no BatteryState source. Reachability requires a real battery percentage." : "Connect a real robot to calculate reachability from its reported battery and distance."}</span></div>}</section>
  </section>;
}
