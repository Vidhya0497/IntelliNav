/*
 * FLOWBOT style reminder: Swiss industrial operations console; warm-white surfaces,
 * deep navy hierarchy, safety orange accents, signal-green health states, fixed left
 * rail, asymmetric map-first layout, and no decorative clutter outside operational data.
 */
import { useEffect, useMemo, useRef, useState } from "react";
import { useLocation } from "wouter";
import {
  Activity,
  AlertTriangle,
  ArrowDownLeft,
  ArrowUpRight,
  BarChart3,
  BatteryCharging,
  Bell,
  Bot,
  Boxes,
  CheckCircle2,
  ChevronDown,
  CircleAlert,
  ClipboardList,
  Clock3,
  Factory,
  Gauge,
  LayoutDashboard,
  LocateFixed,
  MapPinned,
  Menu,
  Minus,
  Navigation,
  Octagon,
  Package,
  Pause,
  Play,
  Plus,
  Radio,
  RefreshCw,
  Route,
  Search,
  Settings,
  ShieldCheck,
  SlidersHorizontal,
  Sparkles,
  Timer,
  Truck,
  Trash2,
  Wifi,
  X,
  Zap,
} from "lucide-react";
import { toast } from "sonner";
import RealRobotPanel, { type ConnectedRobotSnapshot } from "@/components/RealRobotPanel";
import { RobotApi } from "@/services/robotApi";
import { buildTimedMovementCommands, extractMovementCommands, movementActionLabel, movementActionSymbol } from "@/lib/movementCommands";
type RobotStatus =
  | "IDLE"
  | "MOVING_TO_PICKUP"
  | "MOVING_TO_DESTINATION"
  | "CHARGING"
  | "LOW_BATTERY"
  | "PAUSED"
  | "EMERGENCY_STOP"
  | "FAULT"
  | "UNAVAILABLE";

type TaskStatus = "IN PROGRESS" | "PENDING" | "ASSIGNED" | "COMPLETED" | "REASSIGNED" | "PAUSED" | "STOPPED" | "CANCELLED" | "FAILED";

type Point = [number, number];
type RealNavigationResult = { success: boolean; status?: string; message?: string; completed?: boolean };

type Task = {
  id: string;
  pickup: string;
  destination: string;
  assignedRobot: string;
  status: TaskStatus;
  progress: number;
  priority: "URGENT" | "HIGH" | "NORMAL" | "LOW";
  taskType: "STANDARD TRANSPORT" | "PICKUP & DELIVERY" | "PRIORITY DELIVERY" | "MULTI-STOP";
  eta: string;
  batteryRequired: number;
  executionMode?: "single" | "multiple";
  route?: Point[];
  executionStep?: number;
};

type SimulationExecution = { taskId: string; route: Point[]; timer: number; stopRequested: boolean; currentCommand: number };

type AmrForm = { name: string; id: string; model: string; serial: string; battery: string; speed: string; status: RobotStatus; location: string };
type TaskForm = { id: string; pickup: string; destination: string; priority: Task["priority"]; taskType: Task["taskType"]; assignment: "AUTO" | string; details?: string };
type TaskWizardMode = "choose" | "single" | "multiple";
type AllocationResult = { task: TaskForm; robotId: string | null; feasible: boolean; battery: number | null; distance: number; utilization: number; remaining: number | null; explanation: string };
type SettingsConfig = { defaultSpeed: number; maxFleetSize: number; autoAssign: boolean; parallel: boolean; lowBattery: number; criticalBattery: number; chargeComplete: number; reserve: number; autoCharge: boolean; autoReassign: boolean; reassignmentTimeout: number; followPaths: boolean; coordinateIntersections: boolean; collisionAvoidance: boolean; realtime: boolean; showBattery: boolean; showStatus: boolean; showRoute: boolean; dashboardFontSize: number; animationSpeed: "SLOW" | "NORMAL" | "FAST"; defaultPriority: Task["priority"]; realRobotStagingArea: string };
type EnvironmentConfig = { id: string; label: string; warehouse: string; status: "ONLINE" | "MAINTENANCE"; description: string; throughput: number; mapVariant: "north" | "south" | "central" };
type ChargerBayStatus = "AVAILABLE" | "RESERVED" | "OCCUPIED" | "OFFLINE" | "MAINTENANCE";
type ChargerBay = { id: string; status: ChargerBayStatus; robotId: string | null; charge: number | null; output: number; lastEvent: string };
type DeleteTarget = { kind: "robot" | "task"; id: string };
type NotificationItem = { id: string; message: string; timestamp: string; type: "robot" | "task" | "fleet" | "environment" | "system"; read: boolean };

type Robot = {
  id: string;
  label: string;
  status: RobotStatus;
  battery: number;
  position: Point;
  route: Point[];
  routeIndex: number;
  segmentProgress: number;
  taskId: string | null;
  destination: string;
  location: string;
  color: string;
  model: string;
  serial: string;
  speed: number;
  maxSpeed: number;
  lastEvent: string;
  isReal?: boolean;
  apiBaseUrl?: string;
  connectionStatus?: "CONNECTED" | "DISCONNECTED" | "ERROR";
  navigationStatus?: string;
  taskQueue?: string[];
  mapArea?: string;
  positionSource?: "ACTUAL" | "STAGING";
  lastTaskMode?: "single" | "multiple";
};

const routeCatalog: Record<string, Point[]> = {
  receivingToStorageA: [
    [96, 170],
    [96, 198],
    [290, 198],
    [290, 165],
  ],
  receivingToPicking: [
    [96, 170],
    [96, 198],
    [110, 198],
    [110, 326],
  ],
  storageBToAssembly: [
    [470, 165],
    [470, 198],
    [290, 198],
    [290, 326],
  ],
  assemblyToPacking: [
    [370, 326],
    [390, 326],
    [470, 326],
    [470, 350],
  ],
  packingToShipping: [
    [550, 326],
    [585, 326],
    [650, 326],
    [650, 255],
  ],
  toCharging: [
    [650, 350],
    [650, 198],
    [800, 198],
    [800, 165],
  ],
  pickingToPacking: [
    [110, 326],
    [110, 350],
    [470, 350],
    [470, 326],
  ],
};
const warehouseNodes: Record<string, Point> = {
  receiving: [110, 170], storageA: [290, 165], storageB: [470, 165], charging: [800, 165], picking: [110, 326], assembly: [290, 326], packing: [470, 326], shipping: [650, 326],
  rcvAccess: [110, 198], stgAAccess: [290, 198], stgBAccess: [470, 198], chargeApproach: [800, 198], southWest: [110, 350], southCenter: [290, 350], southEast: [470, 350], shippingAccess: [650, 350], northEast: [650, 198],
};
const warehouseEdges: Record<string, string[]> = {
  receiving: ["rcvAccess"], storageA: ["stgAAccess"], storageB: ["stgBAccess"], charging: ["chargeApproach"], picking: ["southWest"], assembly: ["southCenter"], packing: ["southEast"], shipping: ["shippingAccess"],
  rcvAccess: ["receiving", "stgAAccess", "southWest"], stgAAccess: ["storageA", "rcvAccess", "stgBAccess", "southCenter"], stgBAccess: ["storageB", "stgAAccess", "northEast", "southEast"], chargeApproach: ["charging", "northEast"], northEast: ["chargeApproach", "stgBAccess", "shippingAccess"], southWest: ["picking", "rcvAccess", "southCenter"], southCenter: ["assembly", "southWest", "southEast", "stgAAccess"], southEast: ["packing", "southCenter", "shippingAccess", "stgBAccess"], shippingAccess: ["shipping", "southEast", "northEast"],
};
const zoneNodeMap: Record<string, string> = { Receiving: "receiving", "Storage A": "storageA", "Storage B": "storageB", Picking: "picking", Assembly: "assembly", Packing: "packing", Shipping: "shipping", "Charging Station": "charging" };
const warehouseSegments: Point[][] = Array.from(new Set(Object.entries(warehouseEdges).flatMap(([from, targets]) => targets.map((to) => [from, to].sort().join("|"))))).map((key) => { const [from, to] = key.split("|"); return [warehouseNodes[from], warehouseNodes[to]] as Point[]; });
type GraphSearchResult = { nodes: string[]; distance: number };
const shortestWarehouseNodePath = (source: string, destination: string): GraphSearchResult => {
  const start = zoneNodeMap[source] ?? source; const goal = zoneNodeMap[destination] ?? destination;
  if (!warehouseNodes[start] || !warehouseNodes[goal]) return { nodes: [], distance: Infinity };
  const distances: Record<string, number> = Object.fromEntries(Object.keys(warehouseNodes).map((node) => [node, Infinity]));
  const previous: Record<string, string | null> = {}; const unvisited = new Set(Object.keys(warehouseNodes)); distances[start] = 0;
  while (unvisited.size) {
    let node: string | undefined;
    for (const candidate of Array.from(unvisited)) if (!node || distances[candidate] < distances[node]) node = candidate;
    if (!node || distances[node] === Infinity) break;
    unvisited.delete(node); if (node === goal) break;
    for (const next of warehouseEdges[node] ?? []) {
      const a = warehouseNodes[node]; const b = warehouseNodes[next]; const candidateDistance = distances[node] + Math.hypot(b[0] - a[0], b[1] - a[1]);
      if (candidateDistance < distances[next]) { distances[next] = candidateDistance; previous[next] = node; }
    }
  }
  if (distances[goal] === Infinity) return { nodes: [], distance: Infinity };
  const nodes: string[] = []; let cursor: string | null = goal; while (cursor) { nodes.unshift(cursor); cursor = previous[cursor] ?? null; }
  return { nodes, distance: distances[goal] };
};
const shortestWarehouseRoute = (source: string, destination: string): Point[] => {
  const result = shortestWarehouseNodePath(source, destination);
  return result.nodes.map((node) => warehouseNodes[node]);
};
const pointToSegment = (point: Point, a: Point, b: Point): { point: Point; distance: number; along: number } => {
  const dx = b[0] - a[0]; const dy = b[1] - a[1]; const lengthSquared = dx * dx + dy * dy;
  const along = lengthSquared === 0 ? 0 : Math.max(0, Math.min(1, ((point[0] - a[0]) * dx + (point[1] - a[1]) * dy) / lengthSquared));
  const projected: Point = [a[0] + dx * along, a[1] + dy * along];
  return { point: projected, distance: Math.hypot(point[0] - projected[0], point[1] - projected[1]), along };
};
const routeFromCurrentPosition = (position: Point, destination: string): { route: Point[]; distance: number; startNode: string; destinationNode: string } => {
  const destinationNode = zoneNodeMap[destination] ?? destination;
  if (!warehouseNodes[destinationNode]) return { route: [], distance: Infinity, startNode: "unknown", destinationNode };
  const candidates: { route: Point[]; distance: number; startNode: string }[] = [];
  warehouseSegments.forEach(([a, b]) => {
    const projection = pointToSegment(position, a, b);
    const pair = Object.entries(warehouseNodes).find(([, point]) => point[0] === a[0] && point[1] === a[1]);
    const other = Object.entries(warehouseNodes).find(([, point]) => point[0] === b[0] && point[1] === b[1]);
    if (!pair || !other) return;
    [[pair[0], a, projection.along], [other[0], b, 1 - projection.along]].forEach(([node, endpoint, along]) => {
      const result = shortestWarehouseNodePath(String(node), destinationNode); if (!result.nodes.length) return;
      const route = [position, projection.point, endpoint as Point, ...result.nodes.slice(1).map((entry) => warehouseNodes[entry])];
      candidates.push({ route, distance: projection.distance + Math.hypot(projection.point[0] - (endpoint as Point)[0], projection.point[1] - (endpoint as Point)[1]) + result.distance, startNode: String(node) });
    });
  });
  const selected = candidates.filter((candidate) => candidate.route.length > 1).sort((a, b) => a.distance - b.distance)[0];
  return selected ? { route: selected.route.filter((point, index, all) => index === 0 || Math.hypot(point[0] - all[index - 1][0], point[1] - all[index - 1][1]) > 0.5), distance: selected.distance, startNode: selected.startNode, destinationNode } : { route: [], distance: Infinity, startNode: "unknown", destinationNode };
};
const navItems = [
  { label: "Home", path: "/home", icon: LayoutDashboard },
  { label: "Live Map", path: "/live-map", icon: MapPinned },
  { label: "Fleet", path: "/fleet", icon: Bot },
  { label: "Tasks", path: "/tasks", icon: ClipboardList },
  { label: "Charger Bay", path: "/charger-bay", icon: BatteryCharging },
  { label: "Alerts", path: "/alerts", icon: Bell },
  { label: "Analytics", path: "/analytics", icon: BarChart3 },
  { label: "Settings", path: "/settings", icon: Settings },
];

const zoneCatalog = [
  { name: "RECEIVING AREA", x: 35, y: 40, w: 150, h: 112, code: "RCV-01", accent: "orange" },
  { name: "STORAGE ZONE A", x: 210, y: 40, w: 160, h: 112, code: "STG-A", accent: "blue" },
  { name: "STORAGE ZONE B", x: 390, y: 40, w: 160, h: 112, code: "STG-B", accent: "blue" },
  { name: "CHARGING STATION", x: 730, y: 40, w: 150, h: 112, code: "CHG-01", accent: "green" },
  { name: "PICKING AREA", x: 35, y: 215, w: 150, h: 112, code: "PCK-01", accent: "teal" },
  { name: "ASSEMBLY LINE", x: 210, y: 215, w: 160, h: 112, code: "ASM-01", accent: "purple" },
  { name: "PACKING AREA", x: 390, y: 215, w: 160, h: 112, code: "PKG-01", accent: "orange" },
  { name: "SHIPPING AREA", x: 570, y: 215, w: 150, h: 112, code: "SHP-01", accent: "green" },
];

const initialTasks: Task[] = [
  { id: "T-1042", pickup: "Receiving", destination: "Storage A", assignedRobot: "FB-01", status: "IN PROGRESS", progress: 68, priority: "HIGH", taskType: "STANDARD TRANSPORT", eta: "02:18", batteryRequired: 34 },
  { id: "T-1043", pickup: "Picking", destination: "Packing", assignedRobot: "FB-02", status: "IN PROGRESS", progress: 42, priority: "NORMAL", taskType: "PICKUP & DELIVERY", eta: "04:50", batteryRequired: 29 },
  { id: "T-1044", pickup: "Storage B", destination: "Assembly", assignedRobot: "FB-05", status: "IN PROGRESS", progress: 24, priority: "NORMAL", taskType: "STANDARD TRANSPORT", eta: "06:12", batteryRequired: 38 },
  { id: "T-1041", pickup: "Packing", destination: "Shipping", assignedRobot: "—", status: "PENDING", progress: 0, priority: "LOW", taskType: "PRIORITY DELIVERY", eta: "—", batteryRequired: 22 },
  { id: "T-1039", pickup: "Receiving", destination: "Picking", assignedRobot: "FB-04", status: "COMPLETED", progress: 100, priority: "NORMAL", taskType: "STANDARD TRANSPORT", eta: "00:00", batteryRequired: 25 },
];

const environmentCatalog: EnvironmentConfig[] = [
  { id: "north-wh04", label: "North Hub", warehouse: "WH-04", status: "ONLINE", description: "Primary assembly and outbound workspace", throughput: 1248, mapVariant: "north" },
  { id: "north-wh05", label: "North Hub", warehouse: "WH-05", status: "ONLINE", description: "Overflow storage and packing workspace", throughput: 1086, mapVariant: "north" },
  { id: "south-wh01", label: "South Hub", warehouse: "WH-01", status: "ONLINE", description: "South receiving and dispatch workspace", throughput: 932, mapVariant: "south" },
  { id: "central-wh02", label: "Central Hub", warehouse: "WH-02", status: "MAINTENANCE", description: "Central maintenance and staging workspace", throughput: 744, mapVariant: "central" },
];

const initialRobots: Robot[] = [
  {
    id: "FB-01",
    label: "Atlas 01",
    status: "MOVING_TO_PICKUP",
    battery: 84,
    position: [170, 198],
    route: routeCatalog.receivingToStorageA,
    routeIndex: 1,
    segmentProgress: 0.34,
    taskId: "T-1042",
    destination: "Storage A",
    location: "Corridor 02",
    color: "orange",
    model: "FlowBot AMR",
    serial: "FBX-1042",
    speed: 1.2,
    maxSpeed: 1.8,
    lastEvent: "En route to pickup",
  },
  {
    id: "FB-02",
    label: "Atlas 02",
    status: "MOVING_TO_DESTINATION",
    battery: 67,
    position: [205, 350],
    route: routeCatalog.pickingToPacking,
    routeIndex: 2,
    segmentProgress: 0.41,
    taskId: "T-1043",
    destination: "Packing Area",
    location: "Corridor 05",
    color: "teal",
    model: "FlowBot AMR",
    serial: "FBX-1043",
    speed: 1.1,
    maxSpeed: 1.8,
    lastEvent: "Carrying tote · 42%",
  },
  {
    id: "FB-03",
    label: "Atlas 03",
    status: "CHARGING",
    battery: 72,
    position: [800, 166],
    route: routeCatalog.toCharging,
    routeIndex: 3,
    segmentProgress: 1,
    taskId: null,
    destination: "Charging Station",
    location: "Bay 01",
    color: "green",
    model: "FlowBot AMR",
    serial: "FBX-1044",
    speed: 0,
    maxSpeed: 1.8,
    lastEvent: "Charging · safe return at 80%",
  },
  {
    id: "FB-04",
    label: "Atlas 04",
    status: "IDLE",
    battery: 93,
    position: [124, 345],
    route: routeCatalog.receivingToPicking,
    routeIndex: 3,
    segmentProgress: 1,
    taskId: null,
    destination: "—",
    location: "Picking Area",
    color: "slate",
    model: "FlowBot AMR",
    serial: "FBX-1045",
    speed: 0,
    maxSpeed: 1.8,
    lastEvent: "Available for assignment",
  },
  {
    id: "FB-05",
    label: "Atlas 05",
    status: "MOVING_TO_DESTINATION",
    battery: 35,
    position: [470, 198],
    route: routeCatalog.storageBToAssembly,
    routeIndex: 1,
    segmentProgress: 0.62,
    taskId: "T-1044",
    destination: "Assembly Line",
    location: "Corridor 03",
    color: "amber",
    model: "FlowBot AMR",
    serial: "FBX-1046",
    speed: 1,
    maxSpeed: 1.8,
    lastEvent: "Battery watch · 35%",
  },
];

const workspaceSeed = (environment: EnvironmentConfig): { robots: Robot[]; tasks: Task[] } => {
  if (environment.id === "north-wh04") return { robots: initialRobots, tasks: initialTasks };
  const prefix = environment.warehouse.replace("WH-", "");
  const tasks = initialTasks.map((task, index) => ({ ...task, id: `T-${prefix}${String(index + 1).padStart(2, "0")}`, assignedRobot: task.assignedRobot === "—" ? "—" : `FB-${prefix}-${String(index + 1).padStart(2, "0")}`, pickup: environment.id === "south-wh01" ? task.destination : task.pickup, destination: environment.id === "central-wh02" ? "Assembly" : task.destination }));
  const robots = initialRobots.map((robot, index) => ({ ...robot, id: `FB-${prefix}-${String(index + 1).padStart(2, "0")}`, label: `${environment.label.split(" ")[0]} ${String(index + 1).padStart(2, "0")}`, serial: `${robot.serial}-${prefix}`, taskId: robot.taskId ? tasks[index]?.id ?? null : null, lastEvent: `${environment.label} workspace · ${robot.lastEvent}` }));
  return { robots, tasks };
};

const initialWorkspaces = Object.fromEntries(environmentCatalog.map((environment) => [environment.id, workspaceSeed(environment)])) as Record<string, { robots: Robot[]; tasks: Task[] }>;

const REAL_ROBOT_START_AREA = "Receiving Area";
const REAL_ROBOT_FORWARD_SPEED = 0.1;
const REAL_ROBOT_TURN_SPEED = 0.6;
const REAL_ROBOT_TURN_DURATION = 0.8;
const REAL_ROBOT_MAP_UNITS_PER_METER = 10;
const REAL_ROBOT_POSITION_ORIGIN: Point = [96, 170];
const REAL_ROBOT_POSITION_SCALE = 10;
const REAL_ROBOT_MAP_BOUNDS = { minX: 15, maxX: 905, minY: 18, maxY: 372 };
const routeLocationForMapArea: Record<string, string> = { "Receiving Area": "Receiving", "Storage Zone A": "Storage A", "Storage Zone B": "Storage B", "Picking Area": "Picking", "Assembly Line": "Assembly", "Packing Area": "Packing", "Shipping Area": "Shipping", "Charging Station": "Charging Station" };
const mapAreaForRouteLocation: Record<string, string> = Object.fromEntries(Object.entries(routeLocationForMapArea).map(([area, location]) => [location, area]));

const startingLocations: Record<string, { position: Point; label: string; color: string }> = {
  "Receiving Area": { position: [96, 170], label: "Receiving Area", color: "orange" },
  "Picking Area": { position: [124, 345], label: "Picking Area", color: "teal" },
  "Storage Zone A": { position: [290, 165], label: "Storage Zone A", color: "blue" },
  "Storage Zone B": { position: [470, 165], label: "Storage Zone B", color: "blue" },
  "Assembly Line": { position: [290, 326], label: "Assembly Line", color: "purple" },
  "Packing Area": { position: [470, 350], label: "Packing Area", color: "orange" },
  "Charging Station": { position: [800, 166], label: "Charging Station", color: "green" },
};

const routeForTask = (task: Task): Point[] => shortestWarehouseRoute(task.pickup, task.destination);
const realPositionToMapPoint = (position: { x: number; y: number } | null): Point | null => {
  if (!position || !Number.isFinite(position.x) || !Number.isFinite(position.y) || (position.x === 0 && position.y === 0)) return null;
  const point: Point = [REAL_ROBOT_POSITION_ORIGIN[0] + position.x * REAL_ROBOT_POSITION_SCALE, REAL_ROBOT_POSITION_ORIGIN[1] - position.y * REAL_ROBOT_POSITION_SCALE];
  return point[0] >= REAL_ROBOT_MAP_BOUNDS.minX && point[0] <= REAL_ROBOT_MAP_BOUNDS.maxX && point[1] >= REAL_ROBOT_MAP_BOUNDS.minY && point[1] <= REAL_ROBOT_MAP_BOUNDS.maxY ? point : null;
};
const nearestMapArea = (position: Point): string => Object.entries(startingLocations).filter(([label]) => label !== "Charging Station").sort(([, a], [, b]) => Math.hypot(position[0] - a.position[0], position[1] - a.position[1]))[0]?.[0] ?? REAL_ROBOT_START_AREA;
const routeForRobotTask = (robot: Robot, task: Task): Point[] => {
  const destinationLeg = routeFromCurrentPosition(robot.position, task.destination);
  const firstLeg = routeFromCurrentPosition(robot.position, task.pickup);
  const secondLeg = shortestWarehouseRoute(task.pickup, task.destination);
  const route = task.executionMode === "single" ? destinationLeg.route : firstLeg.route.length > 0 && secondLeg.length > 1 ? [...firstLeg.route, ...secondLeg.slice(1)] : [];
  console.debug(`[FLOWBOT] Robot: ${robot.id}`);
  console.debug(`[FLOWBOT] Current location: ${robot.mapArea ?? nearestMapArea(robot.position)}`);
  console.debug(`[FLOWBOT] Destination: ${task.destination}`);
  console.debug(`[FLOWBOT] Calculating shortest path`);
  console.debug(`[FLOWBOT] Candidate routes: ${firstLeg.route.length ? "projected graph route + destination leg" : "none"}`);
  console.debug(`[FLOWBOT] Selected shortest route: ${route.map((point) => `(${Math.round(point[0])},${Math.round(point[1])})`).join(" -> ") || "NO VALID ROUTE"}`);
  console.debug(`[FLOWBOT] Route distance: ${route.length > 1 ? routeDistance(route) : "N/A"}`);
  console.debug(`[FLOWBOT] Movement commands: ${route.length > 1 ? extractMovementCommands(route).map((command) => command.action).join(", ") : "NONE"}`);
  return route;
};

const emptyRobot: Robot = { id: "—", label: "No AMR selected", status: "IDLE", battery: 0, position: [96, 170], route: [], routeIndex: 0, segmentProgress: 0, taskId: null, destination: "—", location: "No robot selected", color: "slate", model: "—", serial: "—", speed: 0, maxSpeed: 0, lastEvent: "Add an AMR to begin reporting" };
const initialChargerBays: ChargerBay[] = [
  { id: "BAY-01", status: "OCCUPIED", robotId: "FB-03", charge: 72, output: 7.2, lastEvent: "FB-03 charging · safe return at 80%" },
  { id: "BAY-02", status: "AVAILABLE", robotId: null, charge: null, output: 0, lastEvent: "Ready for assignment" },
  { id: "BAY-03", status: "AVAILABLE", robotId: null, charge: null, output: 0, lastEvent: "Ready for assignment" },
];

const statusLabel: Record<RobotStatus, string> = {
  IDLE: "IDLE",
  MOVING_TO_PICKUP: "NAVIGATING",
  MOVING_TO_DESTINATION: "NAVIGATING",
  CHARGING: "CHARGING",
  LOW_BATTERY: "LOW BATTERY",
  PAUSED: "PAUSED",
  EMERGENCY_STOP: "E-STOP",
  FAULT: "FAULT",
  UNAVAILABLE: "UNAVAILABLE",
};

const lerpPoint = (a: Point, b: Point, amount: number): Point => [
  a[0] + (b[0] - a[0]) * amount,
  a[1] + (b[1] - a[1]) * amount,
];

const displayPoint = (robot: Robot, robots: Robot[]): Point => {
  const peers = robots.filter((candidate) => candidate.id !== robot.id && Math.hypot(candidate.position[0] - robot.position[0], candidate.position[1] - robot.position[1]) < 26).sort((a, b) => a.id.localeCompare(b.id));
  if (!peers.length) return robot.position;
  const rank = peers.filter((peer) => peer.id < robot.id).length + 1;
  const next = robot.route[robot.routeIndex + 1] ?? robot.position;
  const dx = next[0] - robot.position[0]; const dy = next[1] - robot.position[1];
  const length = Math.max(Math.hypot(dx, dy), 1);
  const normal: Point = [-dy / length, dx / length];
  const offset = Math.min(10, 5 + rank * 3);
  return [robot.position[0] + normal[0] * offset, robot.position[1] + normal[1] * offset];
};

function formatClock(date: Date) {
  return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" });
}

function formatDisplayNumber(value: number | null, suffix = "") { return value == null ? "—" : `${Number(value.toFixed(1))}${suffix}`; }
const MAP_SVG_UNITS_PER_METER = 10;
function routeDistance(route: Point[]) { return route.slice(1).reduce((total, point, index) => total + Math.hypot(point[0] - route[index][0], point[1] - route[index][1]), 0); }
function routeDistanceMeters(route: Point[]) { return routeDistance(route) / MAP_SVG_UNITS_PER_METER; }
function storedDashboardFontSize() {
  if (typeof window === "undefined") return 100;
  const stored = window.localStorage.getItem("flowbot-dashboard-font-size") ?? window.localStorage.getItem("flowbot-live-map-font-size");
  const value = stored === null ? 100 : Number(stored);
  return Number.isFinite(value) ? Math.min(150, Math.max(75, value)) : 100;
}

function batteryTone(battery: number) {
  if (battery < 25) return "danger";
  if (battery < 45) return "warn";
  return "healthy";
}

export default function Home() {
  const [location, setLocation] = useLocation();
  const currentPage = location.split("/")[1] || "home";
  const [robots, setRobots] = useState<Robot[]>(initialRobots);
  const [tasks, setTasks] = useState<Task[]>(initialTasks);
  const [environmentId, setEnvironmentId] = useState("north-wh04");
  const [workspaces, setWorkspaces] = useState(initialWorkspaces);
  const workspacesRef = useRef(workspaces);
  const [openPanel, setOpenPanel] = useState<"search" | "notifications" | "profile" | "environment" | null>(null);
  const [notifications, setNotifications] = useState<NotificationItem[]>([
    { id: "n-1", message: "FB-05 battery below reserve threshold", timestamp: "2 minutes ago", type: "robot", read: false },
    { id: "n-2", message: "T-1041 auto-assigned to FB-04", timestamp: "5 minutes ago", type: "task", read: false },
    { id: "n-3", message: "Settings updated successfully", timestamp: "18 minutes ago", type: "system", read: true },
  ]);
  const [paused, setPaused] = useState(false);
  const [emergency, setEmergency] = useState(false);
  const [speed, setSpeed] = useState(1);
  const [selectedRobot, setSelectedRobot] = useState<string | null>("FB-01");
  const [search, setSearch] = useState("");
  const [mapZoom, setMapZoom] = useState(1);
  const [showMobileNav, setShowMobileNav] = useState(false);
  const [showAddAmr, setShowAddAmr] = useState(false);
  const [showEditAmr, setShowEditAmr] = useState(false);
  const [editingRobot, setEditingRobot] = useState<Robot | null>(null);
  const [showTaskModal, setShowTaskModal] = useState(false);
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const [taskWizardMode, setTaskWizardMode] = useState<TaskWizardMode>("choose");
  const [taskWizardStep, setTaskWizardStep] = useState(0);
  const [taskCandidates, setTaskCandidates] = useState<string[]>([]);
  const [batchCount, setBatchCount] = useState(2);
  const [batchTaskForms, setBatchTaskForms] = useState<TaskForm[]>([]);
  const [allocationResults, setAllocationResults] = useState<AllocationResult[]>([]);
  const [isAnalyzingAllocation, setIsAnalyzingAllocation] = useState(false);
  const [fleetFilter, setFleetFilter] = useState("ALL");
  const [taskFilter, setTaskFilter] = useState("ALL");
  const [lastUpdate, setLastUpdate] = useState(new Date());
  const [amrForm, setAmrForm] = useState<AmrForm>({ name: "Atlas", id: "FB-06", model: "FlowBot AMR", serial: "", battery: "88", speed: "1.2", status: "IDLE", location: "Receiving Area" });
  const [taskForm, setTaskForm] = useState<TaskForm>({ id: "T-1046", pickup: "Receiving", destination: "Storage A", priority: "NORMAL", taskType: "STANDARD TRANSPORT", assignment: "AUTO" });
  const [settings, setSettings] = useState<SettingsConfig>({ defaultSpeed: 1.2, maxFleetSize: 20, autoAssign: true, parallel: true, lowBattery: 20, criticalBattery: 10, chargeComplete: 80, reserve: 10, autoCharge: true, autoReassign: true, reassignmentTimeout: 30, followPaths: true, coordinateIntersections: true, collisionAvoidance: true, realtime: true, showBattery: true, showStatus: true, showRoute: true, dashboardFontSize: storedDashboardFontSize(), animationSpeed: "NORMAL", defaultPriority: "NORMAL", realRobotStagingArea: REAL_ROBOT_START_AREA });
  useEffect(() => { window.localStorage.setItem("flowbot-dashboard-font-size", String(settings.dashboardFontSize)); }, [settings.dashboardFontSize]);
  const [chargerBays, setChargerBays] = useState<ChargerBay[]>(initialChargerBays);
  const [deleteTarget, setDeleteTarget] = useState<DeleteTarget | null>(null);
  const completedTaskIdsRef = useRef(new Set<string>());
  const realRobotApisRef = useRef(new Map<string, RobotApi>());
  const startingQueuedTaskRef = useRef(new Set<string>());
  const activeRealSequencesRef = useRef(new Map<string, string>());
  const simulationExecutionsRef = useRef(new Map<string, SimulationExecution>());
  const simulationControlsRef = useRef({ paused, emergency, speed, realtime: settings.realtime, defaultSpeed: settings.defaultSpeed });
  useEffect(() => { simulationControlsRef.current = { paused, emergency, speed, realtime: settings.realtime, defaultSpeed: settings.defaultSpeed }; }, [paused, emergency, speed, settings.realtime, settings.defaultSpeed]);
  const currentEnvironment = environmentCatalog.find((environment) => environment.id === environmentId) ?? environmentCatalog[0];
  const unreadNotifications = notifications.filter((notification) => !notification.read).length;
  const pushNotification = (message: string, type: NotificationItem["type"]) => setNotifications((current) => [{ id: `n-${Date.now()}-${Math.random()}`, message, timestamp: "just now", type, read: false }, ...current].slice(0, 24));
  const registerConnectedRobot = ({ handshake, telemetry, ip, port, api }: ConnectedRobotSnapshot) => {
    realRobotApisRef.current.set(handshake.robot_id, api);
    const liveStatus: RobotStatus = telemetry.status.status.toLowerCase().includes("moving") ? "MOVING_TO_DESTINATION" : telemetry.status.status.toLowerCase().includes("charg") ? "CHARGING" : telemetry.status.status.toLowerCase().includes("fault") || telemetry.status.status.toLowerCase().includes("error") ? "FAULT" : "IDLE";
    const existing = robots.find((robot) => robot.id === handshake.robot_id);
    const staleSimulationRobot = !existing && selectedRobot ? robots.find((robot) => robot.id === selectedRobot && !robot.isReal) : undefined;
    if (staleSimulationRobot) {
      setTasks((current) => current.map((task) => task.assignedRobot === staleSimulationRobot.id && task.status !== "COMPLETED" ? { ...task, assignedRobot: "—", status: "PENDING", progress: 0, eta: "—" } : task));
      setRobots((current) => current.filter((robot) => robot.id !== staleSimulationRobot.id));
      pushNotification(`${staleSimulationRobot.id} replaced by connected ${handshake.robot_id}`, "robot");
      toast.info(`${staleSimulationRobot.id} removed from the map`, { description: `${handshake.robot_id} is now the active physical robot.` });
    }
    const backendStatus = telemetry.status.status.toLowerCase();
    const reportedCompletion = ["succeeded", "arrived", "completed"].some((value) => backendStatus.includes(value));
    const currentLiveStatus = existing?.taskId && !reportedCompletion && liveStatus === "IDLE" ? "MOVING_TO_DESTINATION" : liveStatus;
    const actualPosition = realPositionToMapPoint(telemetry.position);
    const stagingArea = settings.realRobotStagingArea in startingLocations ? settings.realRobotStagingArea : REAL_ROBOT_START_AREA;
    const staging = startingLocations[stagingArea];
    const mapArea = actualPosition ? nearestMapArea(actualPosition) : existing?.mapArea ?? stagingArea;
    const connectedRobot: Robot = {
      ...(existing ?? { id: handshake.robot_id, label: handshake.robot_id, route: [], routeIndex: 0, segmentProgress: 1, taskId: null, destination: "—", color: "teal", serial: handshake.robot_id, speed: 0, maxSpeed: 1, lastEvent: "Live robot connected" }),
      id: handshake.robot_id,
      label: existing?.label ?? handshake.robot_id,
      status: existing?.taskId && reportedCompletion ? "IDLE" : currentLiveStatus,
      battery: telemetry.battery?.battery ?? existing?.battery ?? 0,
      position: actualPosition ?? (existing?.position ?? staging.position),
      location: actualPosition ? `Live position · ${mapArea}` : `${mapArea} · staging`,
      mapArea,
      positionSource: actualPosition ? "ACTUAL" : "STAGING",
      model: handshake.robot_type,
      isReal: true,
      apiBaseUrl: `http://${ip}:${port}`,
      connectionStatus: "CONNECTED",
      navigationStatus: telemetry.status.status,
      taskId: existing?.taskId && reportedCompletion ? null : existing?.taskId ?? null,
      destination: existing?.taskId && reportedCompletion ? "—" : existing?.destination ?? "—",
      lastEvent: existing?.taskId && reportedCompletion ? "Navigation complete · available" : actualPosition ? `Live position · ${telemetry.status.status}` : `Staged at ${mapArea} · position pending`,
    };
    if (existing?.taskId && reportedCompletion) {
      const completedTaskId = existing.taskId;
      setTasks((current) => current.map((task) => task.id === completedTaskId ? { ...task, status: "COMPLETED", progress: 100, eta: "00:00" } : task));
    }
    setRobots((current) => current.some((robot) => robot.id === connectedRobot.id) ? current.map((robot) => robot.id === connectedRobot.id ? connectedRobot : robot) : [...current, connectedRobot]);
    setSelectedRobot(handshake.robot_id);
    if (existing?.taskId && reportedCompletion && existing.taskQueue?.[0]) void startNextQueuedRealTask(handshake.robot_id, existing.taskQueue[0]);
  };
  const unregisterConnectedRobot = (robotId: string | null) => {
    if (!robotId) return;
    realRobotApisRef.current.delete(robotId);
    setRobots((current) => current.map((robot) => robot.id === robotId ? { ...robot, status: "UNAVAILABLE", connectionStatus: "DISCONNECTED", lastEvent: "Robot disconnected" } : robot));
  };
  const togglePanel = (panel: "search" | "notifications" | "profile" | "environment") => setOpenPanel((current) => current === panel ? null : panel);
  const switchEnvironment = (environment: EnvironmentConfig) => {
    if (environment.id === environmentId) { setOpenPanel(null); return; }
    setWorkspaces((current) => ({ ...current, [environmentId]: { robots, tasks } }));
    const next = workspaces[environment.id] ?? initialWorkspaces[environment.id];
    setEnvironmentId(environment.id); setRobots(next.robots); setTasks(next.tasks); setSelectedRobot(next.robots[0]?.id ?? null); setOpenPanel(null);
    pushNotification(`Environment changed to ${environment.label} · ${environment.warehouse}`, "environment");
    toast.success(`Switched to ${environment.label} · ${environment.warehouse}`, { description: environment.description });
  };
  const [activity, setActivity] = useState([
    { time: "09:41:08", message: "FB-03 entered charging bay", type: "success" },
    { time: "09:40:52", message: "Task T-1042 assigned to FB-01", type: "info" },
    { time: "09:40:16", message: "FB-05 battery below reserve threshold", type: "warning" },
    { time: "09:39:47", message: "Route conflict resolved at Node C-04", type: "info" },
  ]);

  const counts = useMemo(() => ({
    active: robots.filter((robot) => ["MOVING_TO_PICKUP", "MOVING_TO_DESTINATION"].includes(robot.status)).length,
    idle: robots.filter((robot) => robot.status === "IDLE").length,
    charging: robots.filter((robot) => robot.status === "CHARGING").length,
    low: robots.filter((robot) => robot.battery < 40 && robot.status !== "CHARGING").length,
  }), [robots]);

  const selected = robots.find((robot) => robot.id === selectedRobot) ?? robots[0] ?? emptyRobot;
  const activeTasks = tasks.filter((task) => task.status === "IN PROGRESS");
  const filteredTasks = tasks.filter((task) => {
    const matchesSearch = `${task.id} ${task.pickup} ${task.destination} ${task.assignedRobot}`.toLowerCase().includes(search.toLowerCase());
    const matchesFilter = taskFilter === "ALL" || (taskFilter === "MULTI" ? task.taskType === "MULTI-STOP" : task.taskType !== "MULTI-STOP");
    return matchesSearch && matchesFilter;
  });
  const filteredRobots = robots.filter((robot) => {
    if (fleetFilter === "ACTIVE") return robot.status.includes("MOVING");
    if (fleetFilter === "IDLE") return robot.status === "IDLE";
    if (fleetFilter === "CHARGING") return robot.status === "CHARGING";
    if (fleetFilter === "LOW") return robot.battery < settings.lowBattery;
    if (fleetFilter === "FAULT") return robot.status === "FAULT";
    if (fleetFilter === "UNAVAILABLE") return robot.status === "UNAVAILABLE";
    return true;
  });

  const clearSimulationExecution = (robotId: string) => {
    const execution = simulationExecutionsRef.current.get(robotId);
    if (execution) {
      execution.stopRequested = true;
      window.clearInterval(execution.timer);
      simulationExecutionsRef.current.delete(robotId);
      console.debug(`[FLOWBOT] STOP requested for ${robotId}`);
    }
  };
  const startSimulatedTask = (robot: Robot, task: Task) => {
    if (robot.isReal || simulationExecutionsRef.current.has(robot.id)) return;
    const route = routeForRobotTask(robot, task);
    if (route.length < 2) {
      console.warn(`[FLOWBOT] Robot ${robot.id} has NO VALID ROUTE TO DESTINATION for Task ${task.id}`);
      setTasks((current) => current.map((entry) => entry.id === task.id ? { ...entry, status: "FAILED", eta: "—" } : entry));
      setRobots((current) => current.map((entry) => entry.id === robot.id ? { ...entry, status: "FAULT", taskId: null, destination: "—", lastEvent: "NO VALID ROUTE TO DESTINATION" } : entry));
      return;
    }
    clearSimulationExecution(robot.id);
    const execution: SimulationExecution = { taskId: task.id, route, timer: 0, stopRequested: false, currentCommand: -1 };
    simulationExecutionsRef.current.set(robot.id, execution);
    console.debug(`[FLOWBOT] Starting simulation for robot: ${robot.id}`);
    if (task.assignedRobot !== robot.id) console.error(`[FLOWBOT] ERROR: ASSIGNED ROBOT ID CHANGED`, { expected: task.assignedRobot, actual: robot.id });
    console.debug(`[FLOWBOT] Robot ${robot.id} started Task ${task.id}`);
    console.debug(`[FLOWBOT] Movement commands: ${extractMovementCommands(route).map((command) => command.action).join(", ")}`);
    console.debug(`[FLOWBOT] Starting execution`);
    setTasks((current) => current.map((entry) => entry.id === task.id ? { ...entry, assignedRobot: robot.id, status: "IN PROGRESS", progress: 0, eta: "06:00", executionMode: task.executionMode ?? "single", route, executionStep: 0 } : entry));
    setRobots((current) => current.map((entry) => entry.id === robot.id ? { ...entry, status: "MOVING_TO_PICKUP", taskId: task.id, route, routeIndex: 0, segmentProgress: 0, destination: task.destination, lastTaskMode: task.executionMode ?? "single", lastEvent: `Started ${task.id} · following defined route` } : entry));
    execution.timer = window.setInterval(() => {
      const active = simulationExecutionsRef.current.get(robot.id);
      const controls = simulationControlsRef.current;
      if (!active || active.stopRequested || controls.paused || controls.emergency || !controls.realtime) return;
      setRobots((current) => current.map((entry) => {
        if (entry.id !== robot.id || entry.isReal || entry.taskId !== active.taskId) return entry;
        const currentPoint = active.route[entry.routeIndex] ?? active.route[active.route.length - 1];
        const nextPoint = active.route[entry.routeIndex + 1];
        if (!nextPoint) return entry;
        const configuredSpeed = Math.max(0.2, controls.defaultSpeed || entry.maxSpeed || 1.2);
        const nextProgress = entry.segmentProgress + 0.025 * controls.speed * (configuredSpeed / 1.2);
        const nextIndex = nextProgress >= 1 ? entry.routeIndex + 1 : entry.routeIndex;
        const segmentProgress = nextProgress >= 1 ? 0 : nextProgress;
        const position = nextProgress >= 1 ? nextPoint : lerpPoint(currentPoint, nextPoint, nextProgress);
        const finished = nextIndex >= active.route.length - 1;
        const commands = extractMovementCommands(active.route);
        const commandIndex = Math.min(commands.length - 1, Math.floor(((nextIndex + segmentProgress) / Math.max(active.route.length - 1, 1)) * commands.length));
        if (commandIndex !== active.currentCommand) {
          if (active.currentCommand >= 0) console.debug(`[FLOWBOT] Command ${active.currentCommand + 1} completed`);
          active.currentCommand = commandIndex;
          console.debug(`[FLOWBOT] Command ${commandIndex + 1} started`);
          console.debug(`[FLOWBOT] Command type: ${commands[commandIndex]?.action ?? "STOP"}`);
        }
        console.debug(`[FLOWBOT] Updating position for robot: ${robot.id}`);
        console.debug(`[FLOWBOT] Robot ${robot.id} route step ${nextIndex}`);
        setTasks((tasksCurrent) => tasksCurrent.map((taskEntry) => taskEntry.id === active.taskId ? { ...taskEntry, status: finished ? "COMPLETED" : taskEntry.status, progress: finished ? 100 : Math.min(99, Math.round(((nextIndex + segmentProgress) / Math.max(active.route.length - 1, 1)) * 100)), eta: finished ? "00:00" : taskEntry.eta, executionStep: nextIndex, route: active.route } : taskEntry));
        if (finished) {
          window.clearInterval(active.timer);
          simulationExecutionsRef.current.delete(robot.id);
          console.debug(`[FLOWBOT] Robot ${robot.id} reached destination for Task ${active.taskId}`);
          window.setTimeout(() => {
            setActivity((currentActivity) => [{ time: formatClock(new Date()), message: `${active.taskId} completed by ${robot.id}`, type: "success" }, ...currentActivity].slice(0, 6));
            pushNotification(`${active.taskId} completed by ${robot.id}`, "task");
            console.debug(`[FLOWBOT] Robot ${robot.id} Task ${active.taskId} completed`);
            console.debug(`[FLOWBOT] Task completed for robot: ${robot.id}`);
          }, 0);
          return { ...entry, position: nextPoint, routeIndex: active.route.length - 1, segmentProgress: 1, status: "IDLE", taskId: null, taskQueue: (entry.taskQueue ?? []).filter((id) => id !== active.taskId), destination: "—", location: task.destination, mapArea: mapAreaForRouteLocation[task.destination] ?? entry.mapArea, lastEvent: `Task complete · ${task.destination}` } as Robot;
        }
        return { ...entry, position, routeIndex: nextIndex, segmentProgress, status: nextIndex >= 1 ? "MOVING_TO_DESTINATION" : "MOVING_TO_PICKUP", battery: Math.max(12, entry.battery - 0.032 * controls.speed), speed: Math.min(entry.maxSpeed || configuredSpeed, configuredSpeed * controls.speed), lastEvent: `Route step ${nextIndex} · ${task.destination}` } as Robot;
      }));
    }, 260);
  };
  const stopSimulatedRobot = (robotId: string, taskId?: string, status: TaskStatus = "STOPPED") => {
    const execution = simulationExecutionsRef.current.get(robotId);
    if (!execution || (taskId && execution.taskId !== taskId)) return;
    clearSimulationExecution(robotId);
    setTasks((current) => current.map((task) => task.id === execution.taskId ? { ...task, status, eta: status === "STOPPED" ? "STOPPED" : task.eta } : task));
    setRobots((current) => current.map((robot) => robot.id === robotId ? { ...robot, status: "EMERGENCY_STOP", taskId: null, destination: "—", lastEvent: `${status} · ${execution.taskId}` } : robot));
  };

  useEffect(() => {
    const timer = window.setInterval(() => {
      setLastUpdate(new Date());
      if (paused || emergency || !settings.realtime) return;
      setRobots((current) => {
        const proposed = current.map((robot) => {
          if (robot.status === "CHARGING") {
            const newBattery = Math.min(100, robot.battery + 0.85 * speed);
            if (newBattery >= settings.chargeComplete && robot.location.startsWith("BAY-")) window.setTimeout(() => setChargerBays((current) => current.map((bay) => bay.id === robot.location ? { ...bay, status: "AVAILABLE", robotId: null, charge: null, output: 0, lastEvent: "Ready for assignment" } : bay)), 0);
            return {
              ...robot,
              battery: newBattery,
              lastEvent: newBattery >= settings.chargeComplete ? "Charge complete · available" : `Charging · ${Math.round(newBattery)}%`,
              status: newBattery >= settings.chargeComplete ? "IDLE" : "CHARGING",
              location: newBattery >= settings.chargeComplete && robot.location.startsWith("BAY-") ? "Charging Station" : robot.location,
              destination: newBattery >= settings.chargeComplete && robot.location.startsWith("BAY-") ? "—" : robot.destination,
            } as Robot;
          }
          if (robot.status === "IDLE") {
            return robot;
          }
          if (!robot.isReal) return robot;
          if (robot.isReal) {
            return robot;
          }
          if (["PAUSED", "EMERGENCY_STOP", "LOW_BATTERY", "FAULT", "UNAVAILABLE"].includes(robot.status)) {
            if (robot.status === "LOW_BATTERY" && settings.autoCharge && robot.route !== routeCatalog.toCharging) {
              return { ...robot, status: "MOVING_TO_DESTINATION", route: routeCatalog.toCharging, routeIndex: 0, segmentProgress: 0, destination: "Charging Station" } as Robot;
            }
            return robot;
          }

          const route = robot.route;
          const currentPoint = route[robot.routeIndex] ?? route[route.length - 1];
          const nextPoint = route[robot.routeIndex + 1];
          if (!nextPoint) {
            if (robot.destination.startsWith("BAY-")) {
              window.setTimeout(() => setChargerBays((current) => current.map((bay) => bay.id === robot.destination ? { ...bay, status: "OCCUPIED", robotId: robot.id, charge: Math.round(robot.battery), output: 7.2, lastEvent: `${robot.id} docked · charging` } : bay)), 0);
              return { ...robot, status: "CHARGING", battery: Math.max(robot.battery, 18), location: robot.destination, lastEvent: "Docked · charging automatically" } as Robot;
            }
            if (robot.destination === "Charging Station") {
              return { ...robot, status: "CHARGING", battery: Math.max(robot.battery, 18), location: "Bay 01", lastEvent: "Docked · charging automatically" } as Robot;
            }
            return robot;
          }
          const configuredSpeed = Math.max(0.2, settings.defaultSpeed || robot.maxSpeed || 1.2);
          const delta = 0.025 * speed * (configuredSpeed / 1.2);
          const nextProgress = robot.segmentProgress + delta;
          const nextIndex = nextProgress >= 1 ? robot.routeIndex + 1 : robot.routeIndex;
          const segmentProgress = nextProgress >= 1 ? 0 : nextProgress;
          const position = nextProgress >= 1 ? nextPoint : lerpPoint(currentPoint, nextPoint, nextProgress);
          const nextBattery = Math.max(12, robot.battery - 0.032 * speed);
          const routeIsCharging = robot.destination === "Charging Station";
          const shouldCharge = settings.autoCharge && nextBattery < settings.lowBattery && !routeIsCharging;
          const nextRobot = {
            ...robot,
            position,
            routeIndex: nextIndex,
            segmentProgress,
            battery: nextBattery,
            speed: Math.min(robot.maxSpeed || configuredSpeed, configuredSpeed * speed),
            status: shouldCharge ? "LOW_BATTERY" : robot.status,
            route: shouldCharge ? routeCatalog.toCharging : robot.route,
            destination: shouldCharge ? "Charging Station" : robot.destination,
            lastEvent: shouldCharge ? "Low battery · task protected" : robot.lastEvent,
            location: nextIndex >= 2 ? robot.destination : robot.location,
          } as Robot;
          if (nextIndex >= route.length - 1 && robot.taskId && !shouldCharge) {
            return nextRobot;
          }
          return nextRobot;
        });

        if (!settings.autoAssign) return proposed;
        const available = proposed.filter((robot) => robot.status === "IDLE" && robot.battery >= Math.max(28, settings.reserve) && !robot.taskId);
        const pending = tasks.filter((task) => task.status === "PENDING");
        const pairs = settings.parallel ? available.slice(0, pending.length).map((robot, index) => ({ robot, task: pending[index] })) : available[0] && pending[0] ? [{ robot: available[0], task: pending[0] }] : [];
        if (!pairs.length) return proposed;
        const assignment = proposed.map((robot) => {
          const pair = pairs.find((entry) => entry.robot.id === robot.id);
          return pair ? { ...robot, status: "MOVING_TO_PICKUP" as RobotStatus, taskId: pair.task.id, route: routeForTask(pair.task), routeIndex: 0, segmentProgress: 0, destination: pair.task.destination, lastEvent: `Auto-assigned ${pair.task.id}` } as Robot : robot;
        });
        window.setTimeout(() => {
          setTasks((currentTasks) => currentTasks.map((task) => {
            const pair = pairs.find((entry) => entry.task.id === task.id);
            return pair ? { ...task, assignedRobot: pair.robot.id, status: "IN PROGRESS", route: pair.robot.isReal ? task.route : routeForRobotTask(pair.robot, task), executionStep: 0 } : task;
          }));
          pairs.filter(({ robot }) => !robot.isReal).forEach(({ robot, task }) => startSimulatedTask(robot, task));
          setActivity((currentActivity) => [...pairs.map(({ task, robot }) => ({ time: formatClock(new Date()), message: `${task.id} auto-assigned to ${robot.id}`, type: "success" })), ...currentActivity].slice(0, 6));
        }, 0);
        return assignment;
      });
      setTasks((currentTasks) => currentTasks.map((task) => {
        const robot = robots.find((entry) => entry.id === task.assignedRobot);
        if (!robot || !robot.isReal || task.status !== "IN PROGRESS") return task;
        const progress = Math.min(99, Math.round(((robot.routeIndex + robot.segmentProgress) / Math.max(robot.route.length - 1, 1)) * 100));
        return { ...task, progress };
      }));
    }, 260);
    return () => window.clearInterval(timer);
  }, [emergency, paused, speed, tasks, robots, settings.realtime, settings.autoAssign, settings.parallel, settings.reserve]);
  useEffect(() => () => simulationExecutionsRef.current.forEach((_, robotId) => clearSimulationExecution(robotId)), []);

  useEffect(() => {
    robots.filter((robot) => !robot.isReal && robot.status === "IDLE" && !robot.taskId && robot.taskQueue?.length && !simulationExecutionsRef.current.has(robot.id)).forEach((robot) => {
      const nextTask = tasks.find((task) => task.id === robot.taskQueue?.[0]);
      if (nextTask) startSimulatedTask(robot, nextTask);
    });
  }, [robots, tasks]);

  const navigate = (path: string) => {
    setLocation(path);
    setShowMobileNav(false);
  };

  const pauseAll = () => {
    setPaused(true);
    setRobots((current) => current.map((robot) => ["CHARGING", "IDLE"].includes(robot.status) ? robot : { ...robot, status: "PAUSED", lastEvent: "Fleet paused by operator" } as Robot));
    toast("Fleet paused", { description: "All active routes are holding their current position." });
  };

  const resumeAll = () => {
    setPaused(false);
    setEmergency(false);
    setRobots((current) => current.map((robot) => robot.status === "PAUSED" ? { ...robot, status: robot.destination === "Charging Station" ? "LOW_BATTERY" : "MOVING_TO_DESTINATION", lastEvent: "Route resumed" } as Robot : robot));
    toast("Fleet resumed", { description: "Independent robot routes are live again." });
  };

  const emergencyStop = () => {
    simulationExecutionsRef.current.forEach((_, robotId) => stopSimulatedRobot(robotId));
    setEmergency(true);
    setPaused(false);
    activeRealSequencesRef.current.clear();
    void Promise.allSettled(Array.from(realRobotApisRef.current.values()).map((api) => api.stopRobot()));
    setRobots((current) => current.map((robot) => robot.status === "CHARGING" ? robot : { ...robot, status: "EMERGENCY_STOP", lastEvent: "Emergency stop engaged" } as Robot));
    setTasks((current) => current.map((task) => task.status === "IN PROGRESS" && task.assignedRobot !== "—" ? { ...task, status: "STOPPED", eta: "STOPPED" } : task));
    toast.error("Emergency stop engaged", { description: "POST /stop sent; active real-robot sequences were cancelled." });
  };

  const stopSelectedRobot = () => {
    const robot = robots.find((entry) => entry.id === selectedRobot);
    if (!robot) return;
    console.debug(`[FLOWBOT] STOP requested for ${robot.id}`);
    if (robot.isReal) {
      activeRealSequencesRef.current.delete(robot.id);
      const api = realRobotApisRef.current.get(robot.id);
      if (api) void api.stopRobot();
      setTasks((current) => current.map((task) => task.id === robot.taskId ? { ...task, status: "STOPPED", eta: "STOPPED" } : task));
      setRobots((current) => current.map((entry) => entry.id === robot.id ? { ...entry, status: "EMERGENCY_STOP", taskId: null, destination: "—", lastEvent: `STOP requested · ${robot.taskId ?? "no active task"}` } : entry));
    } else {
      stopSimulatedRobot(robot.id, robot.taskId ?? undefined);
    }
    toast.warning(`${robot.id} stopped`, { description: "Only the selected robot and its active task were stopped." });
  };

  const nextTaskId = (offset = 0) => `TSK-${String(100 + tasks.length + offset + 1).padStart(3, "0")}`;
  const openTaskModal = () => {
    setEditingTask(null); setTaskWizardMode("choose"); setTaskWizardStep(0); setTaskCandidates([]); setBatchCount(2); setBatchTaskForms([]); setAllocationResults([]); setIsAnalyzingAllocation(false);
    setTaskForm({ id: nextTaskId(), pickup: "Receiving", destination: "Storage A", priority: settings.defaultPriority, taskType: "STANDARD TRANSPORT", assignment: "AUTO", details: "" });
    setShowTaskModal(true);
  };

  const buildAllocations = (forms: TaskForm[]) => {
    const used = new Set<string>();
    const results = forms.map((form) => {
      const selectedSingleRobotId = taskWizardMode === "single" && forms.length === 1 ? taskCandidates[0] : null;
      const candidates = robots.filter((robot) => taskCandidates.includes(robot.id) && (!selectedSingleRobotId || robot.id === selectedSingleRobotId) && (robot.isReal ? robot.connectionStatus === "CONNECTED" : !used.has(robot.id) && robot.status === "IDLE" && robot.battery >= Math.max(28, settings.reserve)));
      const routeTask = { id: form.id, pickup: form.pickup, destination: form.destination, assignedRobot: "—", status: "PENDING" as TaskStatus, progress: 0, priority: form.priority, taskType: form.taskType, eta: "—", batteryRequired: form.priority === "URGENT" ? 45 : 32 } as Task;
      const ranked = candidates.map((robot) => { const route = routeForRobotTask(robot, routeTask); const distance = route.length > 1 ? routeDistanceMeters(route) : Infinity; return { robot, route, distance, remaining: robot.isReal ? null : Math.round(robot.battery - distance / 18 - (form.priority === "URGENT" ? 12 : 7)), score: distance + (100 - robot.battery) * 0.2 }; }).filter((entry) => Number.isFinite(entry.distance)).sort((a, b) => a.score - b.score);
      const distance = ranked[0]?.distance ?? 0;
      const best = ranked.find((entry) => entry.robot.isReal || (entry.remaining ?? -1) >= settings.reserve);
      if (best && !best.robot.isReal) used.add(best.robot.id);
      return { task: form, robotId: best?.robot.id ?? null, feasible: Boolean(best), battery: best?.robot.isReal ? null : best?.robot.battery ?? null, distance, utilization: best && best.remaining !== null ? Math.round((best.robot.battery - best.remaining) / Math.max(best.robot.battery, 1) * 100) : 0, remaining: best?.remaining ?? null, explanation: best ? `${best.robot.id} selected by shortest safe route · ${best.remaining === null ? "live battery unavailable" : `${best.remaining}% after reserve`}` : "No selected robot remains with enough battery and route capacity" } as AllocationResult;
    });
    setAllocationResults(results); setTaskWizardStep(4);
  };
  const chooseSingleTask = () => { setTaskWizardMode("single"); setTaskWizardStep(1); };
  const chooseMultipleTasks = () => { setTaskWizardMode("multiple"); setTaskWizardStep(1); };
  const continueBatchCount = () => {
    const requested = Number(batchCount) || 0;
    if (requested < 2) { toast.error("Create at least two tasks"); return; }
    if (requested > 12) { toast.error("Create no more than twelve tasks"); return; }
    const count = requested;
    setBatchCount(count); setBatchTaskForms(Array.from({ length: count }, (_, index) => ({ id: nextTaskId(index), pickup: "Receiving", destination: "Storage A", priority: settings.defaultPriority, taskType: "STANDARD TRANSPORT", assignment: "AUTO", details: "" }))); setTaskWizardStep(2);
  };
  const validateSingleDetails = () => { if (!taskForm.pickup || !taskForm.destination || taskForm.pickup === taskForm.destination) { toast.error("Choose different source and destination locations"); return; } setTaskWizardStep(2); };
  const validateBatchDetails = () => { if (batchTaskForms.some((form) => !form.pickup || !form.destination || form.pickup === form.destination)) { toast.error("Complete every task with different source and destination locations"); return; } setTaskWizardStep(3); };
  const runWizardAllocation = () => {
    if (!taskCandidates.length) { toast.error("Select at least one candidate robot"); return; }
    if (isAnalyzingAllocation) return;
    setIsAnalyzingAllocation(true);
    console.debug(`[FLOWBOT] AI allocation analysis started for ${taskWizardMode} task mode`);
    window.setTimeout(() => {
      buildAllocations(taskWizardMode === "single" ? [taskForm] : batchTaskForms);
      setIsAnalyzingAllocation(false);
      console.debug(`[FLOWBOT] AI allocation analysis completed`);
    }, 2000);
  };
  const sendRealNavigation = async (robot: Robot, task: Task): Promise<RealNavigationResult> => {
    const api = realRobotApisRef.current.get(robot.id);
    console.debug(`[FLOWBOT] Starting real execution for robot: ${robot.id}`);
    if (!api) return { success: false, message: "Connected robot API is unavailable." };
    const path = routeForRobotTask(robot, task);
    if (path.length < 2) return { success: false, message: "NO VALID ROUTE TO DESTINATION" };
    const commands = buildTimedMovementCommands(path, { forwardSpeed: REAL_ROBOT_FORWARD_SPEED, turnSpeed: REAL_ROBOT_TURN_SPEED, turnDuration: REAL_ROBOT_TURN_DURATION, mapUnitsPerMeter: REAL_ROBOT_MAP_UNITS_PER_METER });
    const sequenceKey = `${robot.id}:${task.id}`;
    activeRealSequencesRef.current.set(robot.id, sequenceKey);
    try {
      console.debug(`[FLOWBOT] Movement commands: ${commands.map((command) => command.action).join(", ")}`);
      for (const command of commands) {
        if (activeRealSequencesRef.current.get(robot.id) !== sequenceKey) return { success: false, message: "Movement sequence cancelled." };
        console.debug(`[FLOWBOT] Starting command ${command.step}: ${command.action}`);
        if (command.action === "STOP") {
          const stopResponse = await api.stopRobot();
          if (!stopResponse.success) return stopResponse;
          console.debug(`[FLOWBOT] Destination reached`);
          console.debug(`[FLOWBOT] Task completed`);
          return { success: true, completed: true, status: "MOVEMENT_SEQUENCE_COMPLETED", message: "Path command sequence completed and /stop confirmed; physical arrival remains open-loop until position feedback confirms it." };
        }
        const response = await api.move({ linear_x: command.linear_x, angular_z: command.angular_z, duration: command.duration, task_id: task.id, destination: task.destination });
        if (!response.success) return response;
        setRobots((current) => current.map((entry) => entry.id === robot.id ? { ...entry, lastTaskMode: task.executionMode ?? "single", lastEvent: `${command.action} ${command.segment ?? ""}`.trim() } : entry));
      }
      return { success: false, message: "Movement sequence ended without a stop command." };
    } catch (error) {
      return { success: false, message: error instanceof Error ? error.message : "Navigation request failed." };
    } finally {
      if (activeRealSequencesRef.current.get(robot.id) === sequenceKey) activeRealSequencesRef.current.delete(robot.id);
    }
  };
  const startNextQueuedRealTask = async (robotId: string, taskId: string) => {
    const key = `${robotId}:${taskId}`;
    if (startingQueuedTaskRef.current.has(key)) return;
    const robot = robots.find((entry) => entry.id === robotId);
    const task = tasks.find((entry) => entry.id === taskId);
    if (!robot?.isReal || !task) return;
    startingQueuedTaskRef.current.add(key);
    const response = await sendRealNavigation(robot, task);
    if (response.success) {
      const completed = Boolean(response.completed);
      setTasks((current) => current.map((entry) => entry.id === taskId ? { ...entry, status: completed ? "COMPLETED" : "IN PROGRESS", progress: completed ? 100 : entry.progress, eta: completed ? "00:00" : "06:00" } : entry));
      setRobots((current) => current.map((entry) => entry.id === robotId ? { ...entry, status: completed ? "IDLE" : "MOVING_TO_DESTINATION", taskId: completed ? null : taskId, taskQueue: (entry.taskQueue ?? []).filter((id) => id !== taskId), destination: completed ? "—" : task.destination, lastEvent: completed ? `Movement sequence completed · ${taskId}` : `Queued navigation accepted · ${taskId}` } : entry));
      setActivity((current) => [{ time: formatClock(new Date()), message: completed ? `${taskId} completed after route and stop` : `${taskId} started after previous completion`, type: "success" }, ...current].slice(0, 6));
    } else {
      setTasks((current) => current.map((entry) => entry.id === taskId ? { ...entry, status: "FAILED", eta: "—" } : entry));
      setRobots((current) => current.map((entry) => entry.id === robotId ? { ...entry, taskQueue: (entry.taskQueue ?? []).filter((id) => id !== taskId), lastEvent: `Queued navigation failed · ${taskId}` } : entry));
      toast.error(`${taskId} could not start`, { description: response.message ?? "The robot backend rejected the queued request." });
    }
    startingQueuedTaskRef.current.delete(key);
  };
  const confirmWizardTasks = async () => {
    const feasible = allocationResults.filter((result) => result.feasible && result.robotId);
    const taskDrafts: Task[] = allocationResults.map((result) => ({ id: result.task.id, pickup: result.task.pickup, destination: result.task.destination, assignedRobot: result.robotId ?? "—", status: result.feasible ? "IN PROGRESS" : "PENDING", progress: 0, priority: result.task.priority, taskType: result.task.taskType, eta: result.feasible ? "06:00" : "—", batteryRequired: result.task.priority === "URGENT" ? 45 : 32, executionMode: taskWizardMode === "multiple" ? "multiple" : "single" }));
    const activeRealRobots = new Set<string>();
    const startedTaskIds = new Set<string>();
    const queuedByRobot = new Map<string, string[]>();
    const dispatchResults: { taskId: string; accepted: boolean; queued?: boolean; completed?: boolean; message?: string }[] = [];
    const simulatedStarts: { robot: Robot; task: Task }[] = [];
    for (const result of feasible) {
      const robot = robots.find((entry) => entry.id === result.robotId);
      const draft = taskDrafts.find((task) => task.id === result.task.id)!;
      if (!robot) { dispatchResults.push({ taskId: result.task.id, accepted: false, message: "Allocated robot is no longer available." }); continue; }
      console.debug(`[FLOWBOT] TASK CONFIRMED`);
      console.debug(`[FLOWBOT] Selected robot: ${robot.id}`);
      console.debug(`[FLOWBOT] Robot type: ${robot.isReal ? "REAL" : "SIMULATED"}`);
      console.debug(`[FLOWBOT] Task: ${draft.id}`);
      console.debug(`[FLOWBOT] Destination: ${draft.destination}`);
      console.debug(`[FLOWBOT] Current robot location: ${robot.mapArea ?? nearestMapArea(robot.position)}`);
      console.debug(`[FLOWBOT] Route generated: ${routeForRobotTask(robot, draft).map((point) => `(${Math.round(point[0])},${Math.round(point[1])})`).join(" -> ") || "NO VALID ROUTE"}`);
      console.debug(`[FLOWBOT] Movement commands: ${routeForRobotTask(robot, draft).length > 1 ? extractMovementCommands(routeForRobotTask(robot, draft)).map((command) => command.action).join(", ") : "NONE"}`);
      console.debug(`[FLOWBOT] Starting execution`);
      console.debug(`[FLOWBOT] Assigned robot ID: ${draft.assignedRobot}`);
      if (draft.assignedRobot !== robot.id) console.error(`[FLOWBOT] ERROR: ASSIGNED ROBOT ID CHANGED`, { expected: draft.assignedRobot, actual: robot.id });
      if (!robot.isReal) { dispatchResults.push({ taskId: result.task.id, accepted: true }); startedTaskIds.add(result.task.id); simulatedStarts.push({ robot, task: { ...draft, assignedRobot: robot.id, status: "IN PROGRESS", eta: "06:00" } as Task }); continue; }
      if (robot.taskId || activeRealRobots.has(robot.id)) {
        const currentQueue = queuedByRobot.get(robot.id) ?? [...(robot.taskQueue ?? [])];
        queuedByRobot.set(robot.id, [...currentQueue, draft.id]);
        dispatchResults.push({ taskId: draft.id, accepted: true, queued: true, message: "Queued until the active navigation succeeds." });
        continue;
      }
      const response = await sendRealNavigation(robot, draft);
      dispatchResults.push({ taskId: draft.id, accepted: response.success, message: response.message });
      if (response.success) { activeRealRobots.add(robot.id); startedTaskIds.add(draft.id); }
    }
    const acceptedTaskIds = new Set(dispatchResults.filter((result) => result.accepted).map((result) => result.taskId));
    const failedTaskIds = new Set(dispatchResults.filter((result) => !result.accepted).map((result) => result.taskId));
    const queuedTaskIds = new Set(dispatchResults.filter((result) => result.queued).map((result) => result.taskId));
    const completedTaskIds = new Set(dispatchResults.filter((result) => result.completed).map((result) => result.taskId));
    const created: Task[] = taskDrafts.map((task) => failedTaskIds.has(task.id) ? { ...task, status: "FAILED" as TaskStatus, eta: "—" } : completedTaskIds.has(task.id) ? { ...task, status: "COMPLETED" as TaskStatus, progress: 100, eta: "00:00" } : task.status === "IN PROGRESS" && !acceptedTaskIds.has(task.id) ? { ...task, status: "FAILED" as TaskStatus, eta: "—" } : queuedTaskIds.has(task.id) ? { ...task, status: "ASSIGNED" as TaskStatus, eta: "QUEUED" } : task);
    setTasks((current) => [...current, ...created]);
    simulatedStarts.forEach(({ robot, task }) => window.setTimeout(() => startSimulatedTask(robot, task), 0));
    setRobots((current) => current.map((robot) => {
      const allocation = allocationResults.find((result) => result.robotId === robot.id && result.feasible && startedTaskIds.has(result.task.id));
      const queued = queuedByRobot.get(robot.id);
      if (!allocation && !queued) return robot;
      return allocation ? completedTaskIds.has(allocation.task.id) ? { ...robot, status: "IDLE", taskId: null, taskQueue: queued ?? robot.taskQueue ?? [], destination: "—", lastEvent: `Movement sequence completed · ${allocation.task.id}` } as Robot : { ...robot, status: "MOVING_TO_PICKUP", taskId: allocation.task.id, taskQueue: queued ?? robot.taskQueue ?? [], route: robot.isReal ? robot.route : routeForRobotTask(robot, created.find((task) => task.id === allocation.task.id)!), routeIndex: robot.isReal ? robot.routeIndex : 0, segmentProgress: robot.isReal ? robot.segmentProgress : 0, destination: allocation.task.destination, lastEvent: `Navigation accepted · ${allocation.task.id}` } as Robot : { ...robot, taskQueue: queued };
    }));
    setActivity((current) => [...dispatchResults.map((result) => ({ time: formatClock(new Date()), message: result.accepted ? `${result.taskId} navigation accepted` : `${result.taskId} failed for selected robot`, type: result.accepted ? "success" : "warning" })), ...current].slice(0, 6));
    toast.success(`${acceptedTaskIds.size} task${acceptedTaskIds.size === 1 ? "" : "s"} started`, { description: `${created.length - acceptedTaskIds.size} task${created.length - acceptedTaskIds.size === 1 ? " remains" : "s remain"} pending.` });
    setShowTaskModal(false); setAllocationResults([]); setTaskCandidates([]);
  };

  const saveTask = async () => {
    if (taskForm.pickup === taskForm.destination) {
      toast.error("Source and destination must differ");
      return;
    }
    if (editingTask) {
      if (editingTask.status === "IN PROGRESS" && (editingTask.pickup !== taskForm.pickup || editingTask.destination !== taskForm.destination)) {
        toast.error("Active route cannot be changed", { description: "Pause or complete the task before changing its route." });
        return;
      }
      setTasks((current) => current.map((task) => task.id === editingTask.id ? { ...task, pickup: taskForm.pickup, destination: taskForm.destination, priority: taskForm.priority, taskType: taskForm.taskType } : task));
      toast.success(`${editingTask.id} updated`);
    } else {
      const manuallySelected = taskForm.assignment !== "AUTO" ? robots.find((robot) => robot.id === taskForm.assignment) : undefined;
      const eligibleManual = manuallySelected && manuallySelected.status === "IDLE" && manuallySelected.battery >= Math.max(28, settings.reserve) ? manuallySelected : undefined;
      const nextTask: Task = { id: taskForm.id, pickup: taskForm.pickup, destination: taskForm.destination, assignedRobot: eligibleManual ? eligibleManual.id : "—", status: eligibleManual ? "IN PROGRESS" : "PENDING", progress: 0, priority: taskForm.priority, taskType: taskForm.taskType, eta: eligibleManual ? "06:00" : "—", batteryRequired: taskForm.priority === "URGENT" ? 45 : 32, executionMode: "single" };
      let realTaskCompleted = false;
      if (eligibleManual && !eligibleManual.isReal && routeForRobotTask(eligibleManual, nextTask).length < 2) {
        const failedTask = { ...nextTask, status: "FAILED" as TaskStatus, eta: "—" };
        setTasks((current) => [...current, failedTask]);
        toast.error("NO VALID ROUTE TO DESTINATION", { description: `${eligibleManual.id} was not moved.` });
        setShowTaskModal(false);
        return;
      }
      if (eligibleManual?.isReal) {
        const response = await sendRealNavigation(eligibleManual, nextTask);
        if (!response.success) {
          const failedTask = { ...nextTask, status: "FAILED" as TaskStatus, eta: "—" };
          setTasks((current) => [...current, failedTask]);
          setActivity((current) => [{ time: formatClock(new Date()), message: `${failedTask.id} failed for selected robot ${eligibleManual.id}`, type: "warning" }, ...current].slice(0, 6));
          toast.error("Navigation request failed", { description: response.message ?? "The selected robot backend did not accept the task." });
          setShowTaskModal(false);
          return;
        }
        realTaskCompleted = Boolean(response.completed);
      }
      const taskToCreate = realTaskCompleted ? { ...nextTask, status: "COMPLETED" as TaskStatus, progress: 100, eta: "00:00" } : nextTask;
      setTasks((current) => [...current, taskToCreate]);
      if (eligibleManual) setRobots((current) => current.map((robot) => robot.id === eligibleManual.id ? realTaskCompleted ? { ...robot, status: "IDLE", taskId: null, destination: "—", lastEvent: `Movement sequence completed · ${nextTask.id}` } : { ...robot, status: "MOVING_TO_PICKUP", taskId: nextTask.id, route: robot.isReal ? robot.route : routeForRobotTask(robot, nextTask), routeIndex: robot.isReal ? robot.routeIndex : 0, segmentProgress: robot.isReal ? robot.segmentProgress : 0, destination: nextTask.destination, lastEvent: `${robot.isReal ? "Navigation accepted" : "Manually assigned"} · ${nextTask.id}` } : robot));
      if (eligibleManual && !eligibleManual.isReal) window.setTimeout(() => startSimulatedTask(eligibleManual, taskToCreate), 0);
      setActivity((current) => [{ time: formatClock(new Date()), message: eligibleManual ? `${nextTask.id} assigned to ${eligibleManual.id}` : `${nextTask.id} added to dynamic queue`, type: "info" }, ...current].slice(0, 6));
      toast.success(eligibleManual ? `${nextTask.id} assigned` : "Task added to queue", { description: eligibleManual ? `${eligibleManual.id} is moving on a defined route.` : `${nextTask.id} will be assigned by battery-aware scheduling.` });
    }
    setShowTaskModal(false);
  };

  const allocatePending = () => {
    const available = robots.filter((robot) => robot.status === "IDLE" && robot.battery >= Math.max(28, settings.reserve) && !robot.taskId);
    const pending = tasks.filter((task) => task.status === "PENDING");
    const pairs = settings.parallel ? available.slice(0, pending.length).map((robot, index) => ({ robot, task: pending[index] })) : available[0] && pending[0] ? [{ robot: available[0], task: pending[0] }] : [];
    if (!pairs.length) { toast("No eligible pairing found", { description: "Check pending work, battery reserve, and robot availability." }); return; }
    setRobots((current) => current.map((robot) => { const pair = pairs.find((entry) => entry.robot.id === robot.id); return pair ? { ...robot, status: "MOVING_TO_PICKUP", taskId: pair.task.id, route: routeForTask(pair.task), routeIndex: 0, segmentProgress: 0, destination: pair.task.destination, lastEvent: `Allocated ${pair.task.id}` } : robot; }));
    setTasks((current) => current.map((task) => { const pair = pairs.find((entry) => entry.task.id === task.id); return pair ? { ...task, assignedRobot: pair.robot.id, status: "IN PROGRESS", route: pair.robot.isReal ? task.route : routeForRobotTask(pair.robot, task), executionStep: 0 } : task; }));
    pairs.filter(({ robot }) => !robot.isReal).forEach(({ robot, task }) => window.setTimeout(() => startSimulatedTask(robot, task), 0));
    setActivity((current) => [...pairs.map(({ task, robot }) => ({ time: formatClock(new Date()), message: `${task.id} allocated to ${robot.id}`, type: "success" })), ...current].slice(0, 6));
    toast.success(`${pairs.length} pending task${pairs.length === 1 ? "" : "s"} allocated`, { description: "Eligible robots are moving independently on defined paths." });
  };

  const openEditAmr = (robot: Robot) => {
    setEditingRobot(robot);
    setAmrForm({ name: robot.label, id: robot.id, model: robot.model, serial: robot.serial, battery: String(Math.round(robot.battery)), speed: String(robot.maxSpeed), status: robot.status, location: robot.location });
    setShowEditAmr(true);
  };

  const saveAmrEdit = () => {
    if (!editingRobot) return;
    const id = amrForm.id.trim().toUpperCase();
    if (!id || robots.some((robot) => robot.id === id && robot.id !== editingRobot.id)) { toast.error("AMR ID must be unique"); return; }
    const nextBattery = Math.max(1, Math.min(100, Number(amrForm.battery) || editingRobot.battery));
    setRobots((current) => current.map((robot) => robot.id === editingRobot.id ? { ...robot, id, label: amrForm.name.trim() || robot.label, model: amrForm.model.trim() || robot.model, serial: amrForm.serial.trim() || robot.serial, battery: nextBattery, maxSpeed: Math.max(0, Number(amrForm.speed) || robot.maxSpeed), speed: robot.status.includes("MOVING") ? robot.speed : 0 } : robot));
    setTasks((current) => current.map((task) => task.assignedRobot === editingRobot.id ? { ...task, assignedRobot: id } : task));
    if (selectedRobot === editingRobot.id) setSelectedRobot(id);
    setShowEditAmr(false); setEditingRobot(null);
    toast.success(`${id} updated`, { description: "Fleet identity and operating configuration saved." });
  };

  const resetSimulation = () => {
    simulationExecutionsRef.current.forEach((_, robotId) => clearSimulationExecution(robotId));
    setPaused(true); setEmergency(false); setRobots(initialRobots); setTasks(initialTasks); setSelectedRobot("FB-01");
    setActivity((current) => [{ time: formatClock(new Date()), message: "Simulation reset by operator", type: "warning" }, ...current].slice(0, 6));
    toast.success("Simulation reset", { description: "Robots and tasks are back to the baseline operating state." });
  };

  const clearCompletedTasks = () => {
    const completed = tasks.filter((task) => task.status === "COMPLETED").length;
    setTasks((current) => current.filter((task) => task.status !== "COMPLETED"));
    toast.success(`${completed} completed task${completed === 1 ? "" : "s"} cleared`, { description: "Active and pending work was preserved." });
  };

  const addAmr = () => {
    if (robots.length >= settings.maxFleetSize) { toast.error("Maximum fleet size reached", { description: `Increase the limit in Settings before registering another AMR.` }); return; }
    const id = amrForm.id.trim().toUpperCase();
    if (!id || robots.some((robot) => robot.id === id)) {
      toast.error("AMR ID must be unique", { description: "Choose a different fleet identifier before adding the robot." });
      return;
    }
    const start = startingLocations[amrForm.location] ?? startingLocations["Receiving Area"];
    const battery = Math.max(1, Math.min(100, Number(amrForm.battery) || 80));
    const isCharging = amrForm.status === "CHARGING";
    const visualColor = start.color === "blue" ? "teal" : start.color === "purple" ? "slate" : start.color;
    const dockedStart = startingLocations["Charging Station"];
    const robot: Robot = {
      id,
      label: amrForm.name.trim() || id,
      status: isCharging ? "CHARGING" : amrForm.status === "FAULT" ? "FAULT" : amrForm.status === "UNAVAILABLE" ? "UNAVAILABLE" : "IDLE",
      battery,
      position: isCharging ? dockedStart.position : start.position,
      route: isCharging ? routeCatalog.toCharging : [],
      routeIndex: isCharging ? routeCatalog.toCharging.length - 1 : 0,
      segmentProgress: isCharging ? 1 : 0,
      taskId: null,
      destination: isCharging ? "Charging Station" : "—",
      location: isCharging ? dockedStart.label : start.label,
      color: visualColor,
      model: amrForm.model.trim() || "FlowBot AMR",
      serial: amrForm.serial.trim() || `FBX-${id.replace(/[^A-Z0-9]/g, "")}`,
      speed: isCharging ? 0 : Math.max(0, Number(amrForm.speed) || 1.2),
      maxSpeed: Math.max(0, Number(amrForm.speed) || 1.2),
      lastEvent: isCharging ? "Charging · added to bay" : amrForm.status === "FAULT" ? "Fault state · inspection required" : amrForm.status === "UNAVAILABLE" ? "Unavailable · awaiting service" : "Available · awaiting task assignment",
    };
    setRobots((current) => [...current, robot]);
    setSelectedRobot(id);
    setShowAddAmr(false);
    setAmrForm({ name: "Atlas", id: `FB-${String(robots.length + 2).padStart(2, "0")}`, model: "FlowBot AMR", serial: "", battery: "88", speed: "1.2", status: "IDLE", location: "Receiving Area" });
    setActivity((current) => [{ time: formatClock(new Date()), message: `${id} added to fleet · stationary until assigned`, type: "success" }, ...current].slice(0, 6));
    pushNotification(`A new AMR has been registered: ${id}`, "fleet");
    toast.success(`${id} added to fleet`, { description: "The AMR is visible on the map and will remain stationary until it receives a task." });
  };

  const deleteAmr = (robot: Robot) => setDeleteTarget({ kind: "robot", id: robot.id });
  const performDeleteAmr = (robot: Robot) => {
    clearSimulationExecution(robot.id);
    const ownedTask = tasks.find((task) => task.assignedRobot === robot.id && task.status === "IN PROGRESS");
    setRobots((current) => current.filter((entry) => entry.id !== robot.id));
    if (selectedRobot === robot.id) setSelectedRobot(null);
    if (ownedTask) setTasks((current) => current.map((task) => task.id === ownedTask.id ? { ...task, assignedRobot: "—", status: "PENDING", progress: Math.max(0, task.progress - 5), eta: "—" } : task));
    setActivity((current) => [{ time: formatClock(new Date()), message: ownedTask ? `${robot.id} removed · ${ownedTask.id} returned to queue` : `${robot.id} removed from fleet`, type: "warning" }, ...current].slice(0, 6));
    pushNotification(`${robot.id} has been removed from the fleet`, "fleet");
    toast(`${robot.id} deleted`, { description: ownedTask ? `${ownedTask.id} is pending reassignment.` : "The remaining fleet continues operating." });
  };

  const deleteTask = (task: Task) => setDeleteTarget({ kind: "task", id: task.id });
  const performDeleteTask = (task: Task) => {
    setTasks((current) => current.filter((entry) => entry.id !== task.id));
    if (task.assignedRobot !== "—") {
      setRobots((current) => current.map((robot) => robot.id === task.assignedRobot ? {
        ...robot,
        taskId: null,
        status: robot.status === "CHARGING" || robot.battery < 28 ? robot.status : "IDLE",
        route: robot.status === "CHARGING" || robot.battery < 28 ? robot.route : [],
        routeIndex: robot.status === "CHARGING" || robot.battery < 28 ? robot.routeIndex : 0,
        segmentProgress: robot.status === "CHARGING" || robot.battery < 28 ? robot.segmentProgress : 0,
        destination: robot.status === "CHARGING" || robot.battery < 28 ? robot.destination : "—",
        lastEvent: robot.status === "CHARGING" || robot.battery < 28 ? robot.lastEvent : `Task ${task.id} cancelled · available`,
      } as Robot : robot));
    }
    setActivity((current) => [{ time: formatClock(new Date()), message: `${task.id} deleted · robot released safely`, type: "warning" }, ...current].slice(0, 6));
    toast(`${task.id} deleted`, { description: task.assignedRobot === "—" ? "Removed from the pending queue." : `${task.assignedRobot} is available for another task.` });
  };

  const confirmDeleteTarget = () => {
    if (!deleteTarget) return;
    if (deleteTarget.kind === "robot") {
      const robot = robots.find((entry) => entry.id === deleteTarget.id);
      const busy = robot && (Boolean(robot.taskId) || ["MOVING_TO_PICKUP", "MOVING_TO_DESTINATION", "CHARGING", "LOW_BATTERY"].includes(robot.status));
      if (!robot) { toast.error("Unable to delete robot", { description: `${deleteTarget.id} is no longer in the fleet.` }); setDeleteTarget(null); return; }
      if (busy) { toast.error("Unable to delete robot", { description: `${robot.id} cannot be deleted because it is currently assigned to an active operation.` }); setDeleteTarget(null); return; }
      performDeleteAmr(robot);
    } else {
      const task = tasks.find((entry) => entry.id === deleteTarget.id);
      if (!task) { toast.error("Unable to delete task", { description: `${deleteTarget.id} is no longer in the task list.` }); setDeleteTarget(null); return; }
      performDeleteTask(task);
    }
    setDeleteTarget(null);
  };
  useEffect(() => {
    if (!openPanel) return;
    const onKeyDown = (event: KeyboardEvent) => { if (event.key === "Escape") setOpenPanel(null); };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [openPanel]);

  const searchQuery = search.trim().toLowerCase();
  const searchRobots = robots.filter((robot) => `${robot.id} ${robot.label} ${robot.model} ${robot.serial}`.toLowerCase().includes(searchQuery)).slice(0, 4);
  const searchTasks = tasks.filter((task) => `${task.id} ${task.pickup} ${task.destination}`.toLowerCase().includes(searchQuery)).slice(0, 4);
  const searchLocations = Object.keys(startingLocations).filter((item) => item.toLowerCase().includes(searchQuery)).slice(0, 4);
  const searchPages = navItems.filter((item) => item.label.toLowerCase().includes(searchQuery)).slice(0, 4);

	  return (
	    <div className="app-shell" style={{ "--dashboard-font-scale": settings.dashboardFontSize / 100 } as React.CSSProperties}>
	      <aside className={`sidebar ${showMobileNav ? "sidebar-open" : ""}`}>
	        <div className="brand-lockup">
	          <svg className="brand-mark" viewBox="0 0 32 32" role="img" aria-label="Flowbot mark">
	            <rect x="3" y="11" width="18" height="12" rx="3" fill="#f5fbf8" />
	            <path d="M9 11 14 4l5 7" fill="none" stroke="#e86a33" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
	            <path d="M21 17h7M25 13l4 4-4 4" fill="none" stroke="#e86a33" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
	            <circle cx="8" cy="27" r="2" fill="#55c793" />
	            <circle cx="20" cy="27" r="2" fill="#55c793" />
	          </svg>
	          <div>
            <div className="brand-name">FLOWBOT</div>
            <div className="brand-subtitle">FLEET CONTROL</div>
          </div>
          <button className="icon-button sidebar-close" onClick={() => setShowMobileNav(false)} aria-label="Close navigation"><X size={16} /></button>
        </div>

        <button className="site-switcher" onClick={() => togglePanel("environment")} aria-expanded={openPanel === "environment"}>
          <div className="site-dot" />
          <div><span className="eyebrow">ACTIVE SITE</span><strong>{currentEnvironment.label} · {currentEnvironment.warehouse}</strong></div>
          <ChevronDown size={15} className="muted-icon" />
        </button>

        <div className="nav-group">
          <span className="nav-caption">OPERATIONS</span>
          {navItems.slice(0, 5).map(({ label, path, icon: Icon }) => (
            <button key={path} className={`nav-item ${currentPage === path.slice(1) ? "active" : ""}`} onClick={() => navigate(path)}>
              <Icon size={17} strokeWidth={1.8} /><span>{label}</span>{label === "Live Map" && <span className="live-pip" />}
            </button>
          ))}
        </div>
        <div className="nav-group nav-group-secondary">
          <span className="nav-caption">INSIGHT</span>
          {navItems.slice(5, 7).map(({ label, path, icon: Icon }) => (
            <button key={path} className={`nav-item ${currentPage === path.slice(1) ? "active" : ""}`} onClick={() => navigate(path)}>
              <Icon size={17} strokeWidth={1.8} /><span>{label}</span>{label === "Alerts" && counts.low > 0 && <span className="alert-count">{counts.low}</span>}
            </button>
          ))}
        </div>
        <div className="nav-group nav-group-secondary">
          <span className="nav-caption">SYSTEM</span>
          <button className={`nav-item ${currentPage === "settings" ? "active" : ""}`} onClick={() => navigate("/settings")}><Settings size={17} strokeWidth={1.8} /><span>Settings</span></button>
        </div>

        <div className="sidebar-footer">
          <button className="operator-card" onClick={() => togglePanel("profile")} aria-expanded={openPanel === "profile"}>
            <div className="operator-avatar">JM</div>
            <div><strong>Jordan Mills</strong><span>Shift supervisor</span></div>
            <MoreIcon />
          </button>
          <div className="connection-line"><Wifi size={13} /><span>Fleet link stable</span><span className="connection-time">32ms</span></div>
        </div>
      </aside>

      {showMobileNav && <button className="mobile-scrim" onClick={() => setShowMobileNav(false)} aria-label="Close navigation" />}

      <main className="main-shell">
        <header className="topbar">
          <button className="icon-button mobile-menu" onClick={() => setShowMobileNav(true)} aria-label="Open navigation"><Menu size={19} /></button>
          <div className="breadcrumb"><span>{currentEnvironment.label}</span><span className="breadcrumb-separator">/</span><strong>{currentPage === "live-map" ? "Live Map" : currentPage === "charger-bay" ? "Charger Bay" : currentPage.charAt(0).toUpperCase() + currentPage.slice(1)}</strong></div>
          <div className="topbar-actions">
            <div className="topbar-sync"><span className="sync-dot" /> SYNCED <span className="sync-time">{formatClock(lastUpdate)}</span></div>
            <button className="icon-button" onClick={() => togglePanel("search")} aria-label="Search" aria-expanded={openPanel === "search"}><Search size={17} /></button>
            <button className="icon-button notification-button" onClick={() => togglePanel("notifications")} aria-label="Notifications" aria-expanded={openPanel === "notifications"}><Bell size={17} /><span />{unreadNotifications > 0 && <b>{unreadNotifications}</b>}</button>
            <div className="topbar-divider" />
            <button className="topbar-avatar" onClick={() => togglePanel("profile")} aria-label="Open profile" aria-expanded={openPanel === "profile"}>JM</button>
          </div>
        </header>

        <div className="page-content">
          {currentPage === "home" && <HomeView robots={robots} tasks={tasks} counts={counts} activity={activity} onNavigate={navigate} onCreateTask={openTaskModal} environment={currentEnvironment} />}
          {currentPage === "live-map" && <><LiveMapView robots={robots} tasks={tasks} selectedRobot={selected} counts={counts} mapZoom={mapZoom} setMapZoom={setMapZoom} onSelectRobot={setSelectedRobot} speed={speed} setSpeed={setSpeed} paused={paused} emergency={emergency} pauseAll={pauseAll} resumeAll={resumeAll} emergencyStop={emergencyStop} activity={activity} environment={currentEnvironment} stopSelectedRobot={stopSelectedRobot} showBattery={settings.showBattery} showStatus={settings.showStatus} showRoute={settings.showRoute} dashboardFontSize={settings.dashboardFontSize} /><RealRobotPanel onConnected={registerConnectedRobot} onDisconnected={unregisterConnectedRobot} /></>}
          {currentPage === "fleet" && <FleetView robots={robots} tasks={tasks} search={search} setSearch={setSearch} onSelectRobot={(id) => { setSelectedRobot(id); navigate("/live-map"); }} onAddAmr={() => setShowAddAmr(true)} onEditAmr={openEditAmr} onDeleteAmr={deleteAmr} fleetFilter={fleetFilter} setFleetFilter={setFleetFilter} />}
          {currentPage === "tasks" && <TasksView tasks={filteredTasks} search={search} setSearch={setSearch} onCreateTask={openTaskModal} onDeleteTask={deleteTask} onEditTask={(task) => { setEditingTask(task); setTaskForm({ id: task.id, pickup: task.pickup, destination: task.destination, priority: task.priority, taskType: task.taskType, assignment: task.assignedRobot === "—" ? "AUTO" : task.assignedRobot }); setShowTaskModal(true); }} onAllocate={allocatePending} taskFilter={taskFilter} setTaskFilter={setTaskFilter} />}
          {currentPage === "charger-bay" && <ChargerBayView robots={robots} bays={chargerBays} environment={currentEnvironment} onSendToCharger={(robotId, bayId) => {
            const robot = robots.find((entry) => entry.id === robotId);
            const bay = chargerBays.find((entry) => entry.id === bayId);
            const eligible = robot && ["IDLE", "PAUSED"].includes(robot.status) && !robot.taskId && robot.battery > settings.criticalBattery;
            if (!robot || !bay || !eligible || bay.status !== "AVAILABLE") { toast.error("Assignment unavailable", { description: "The robot or charging bay changed state. Refresh your selection and try again." }); return; }
            setChargerBays((current) => current.map((entry) => entry.id === bayId ? { ...entry, status: "RESERVED", robotId, lastEvent: `${robotId} en route to charger` } : entry));
            setRobots((current) => current.map((entry) => entry.id === robotId ? { ...entry, status: "MOVING_TO_DESTINATION", route: routeCatalog.toCharging, routeIndex: 0, segmentProgress: 0, destination: bayId, location: "En route to charger", lastEvent: `Reserved ${bayId} · moving to charge` } : entry));
            setSelectedRobot(robotId); setActivity((current) => [{ time: formatClock(new Date()), message: `${robotId} sent to ${bayId}`, type: "info" }, ...current].slice(0, 6)); pushNotification(`${robotId} reserved ${bayId}`, "robot"); toast.success(`${robotId} sent to ${bayId}`, { description: "The bay is reserved and the robot is following the charging route." });
          }} />}
          {currentPage === "alerts" && <AlertsView robots={robots} activity={activity} onNavigate={navigate} environment={currentEnvironment} />}
          {currentPage === "analytics" && <AnalyticsView robots={robots} tasks={tasks} environment={currentEnvironment} />}
          {currentPage === "settings" && <SettingsView speed={speed} setSpeed={setSpeed} settings={settings} setSettings={setSettings} onReset={resetSimulation} onClearCompleted={clearCompletedTasks} />}
        </div>
      </main>
      {openPanel && <button className="panel-scrim" aria-label="Close panel" onClick={() => setOpenPanel(null)} />}
      {openPanel === "environment" && <EnvironmentPanel current={currentEnvironment} environments={environmentCatalog} onSelect={switchEnvironment} />}
      {openPanel === "search" && <SearchPanel query={search} setQuery={setSearch} robots={searchRobots} tasks={searchTasks} locations={searchLocations} pages={searchPages} onRobot={(id) => { setSelectedRobot(id); setOpenPanel(null); navigate("/live-map"); }} onTask={(id) => { setSearch(id); setOpenPanel(null); navigate("/tasks"); }} onLocation={() => { setOpenPanel(null); navigate("/live-map"); }} onPage={(path) => { setOpenPanel(null); navigate(path); }} />}
      {openPanel === "notifications" && <NotificationPanel notifications={notifications} onRead={(id) => setNotifications((current) => current.map((item) => item.id === id ? { ...item, read: true } : item))} onReadAll={() => setNotifications((current) => current.map((item) => ({ ...item, read: true })))} onClear={() => setNotifications([])} />}
      {openPanel === "profile" && <ProfilePanel environment={currentEnvironment} onSettings={() => { setOpenPanel(null); navigate("/settings"); }} />}
      {showAddAmr && <AddAmrModal form={amrForm} setForm={setAmrForm} mode="register" onClose={() => setShowAddAmr(false)} onSubmit={addAmr} />}
      {showEditAmr && editingRobot && <AddAmrModal form={amrForm} setForm={setAmrForm} mode="edit" onClose={() => { setShowEditAmr(false); setEditingRobot(null); }} onSubmit={saveAmrEdit} />}
      {showTaskModal && <TaskModal form={taskForm} setForm={setTaskForm} editing={Boolean(editingTask)} robots={robots} isAnalyzingAllocation={isAnalyzingAllocation} onClose={() => { setShowTaskModal(false); setIsAnalyzingAllocation(false); }} onSubmit={saveTask} mode={taskWizardMode} step={taskWizardStep} setMode={setTaskWizardMode} setStep={setTaskWizardStep} candidates={taskCandidates} setCandidates={setTaskCandidates} batchCount={batchCount} setBatchCount={setBatchCount} batchForms={batchTaskForms} setBatchForms={setBatchTaskForms} allocations={allocationResults} onChooseSingle={chooseSingleTask} onChooseMultiple={chooseMultipleTasks} onContinueBatch={continueBatchCount} onValidateSingle={validateSingleDetails} onValidateBatch={validateBatchDetails} onRunAllocation={runWizardAllocation} onConfirmAllocations={confirmWizardTasks} />}
      {deleteTarget && <DeleteConfirmModal target={deleteTarget} robots={robots} tasks={tasks} onCancel={() => setDeleteTarget(null)} onConfirm={confirmDeleteTarget} />}
    </div>
  );
}

function DeleteConfirmModal({ target, robots, tasks, onCancel, onConfirm }: { target: DeleteTarget; robots: Robot[]; tasks: Task[]; onCancel: () => void; onConfirm: () => void }) {
  const robot = target.kind === "robot" ? robots.find((entry) => entry.id === target.id) : undefined;
  const task = target.kind === "task" ? tasks.find((entry) => entry.id === target.id) : undefined;
  const inProgress = task?.status === "IN PROGRESS";
  useEffect(() => { const onKeyDown = (event: KeyboardEvent) => { if (event.key === "Escape") onCancel(); }; window.addEventListener("keydown", onKeyDown); return () => window.removeEventListener("keydown", onKeyDown); }, [onCancel]);
  return <div className="confirm-overlay" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) onCancel(); }}><section className="confirm-modal" role="dialog" aria-modal="true" aria-labelledby="confirm-title"><button className="confirm-close" onClick={onCancel} aria-label="Close confirmation"><X size={16} /></button><div className="confirm-icon"><AlertTriangle size={18} /></div><span className="eyebrow">{target.kind === "robot" ? "FLEET CONTROL" : "WORK QUEUE"}</span><h2 id="confirm-title">{inProgress ? "Task Is In Progress" : target.kind === "robot" ? "Delete Robot?" : "Delete Task?"}</h2><p>{inProgress ? `This task is currently assigned to ${task?.assignedRobot ?? "a robot"}. Do you want to cancel the task before deleting it?` : target.kind === "robot" ? `Do you want to delete ${robot?.id ?? target.id} from the fleet?` : `Do you want to delete ${task?.id ?? target.id}?`}</p><small>{inProgress ? "The assigned robot will be released and the task will be removed." : target.kind === "robot" ? "This action will remove the robot from the fleet." : "This action will permanently remove the task from the task list."}</small><div className="confirm-actions"><button className="button button-quiet" onClick={onCancel}>{inProgress ? "No, Keep Task" : "No"}</button><button className="button confirm-danger" onClick={onConfirm}>{inProgress ? "Yes, Cancel & Delete" : "Yes, Delete"}</button></div></section></div>;
}

function ChargerBayView({ robots, bays, onSendToCharger, environment }: { robots: Robot[]; bays: ChargerBay[]; onSendToCharger: (robotId: string, bayId: string) => void; environment: EnvironmentConfig }) {
  const eligibleRobots = robots.filter((robot) => ["IDLE", "PAUSED"].includes(robot.status) && !robot.taskId && robot.battery > 10);
  const availableBays = bays.filter((bay) => bay.status === "AVAILABLE");
  const [robotId, setRobotId] = useState(eligibleRobots[0]?.id ?? "");
  const [bayId, setBayId] = useState(availableBays[0]?.id ?? "");
  useEffect(() => { if (!eligibleRobots.some((robot) => robot.id === robotId)) setRobotId(eligibleRobots[0]?.id ?? ""); }, [eligibleRobots, robotId]);
  useEffect(() => { if (!availableBays.some((bay) => bay.id === bayId)) setBayId(availableBays[0]?.id ?? ""); }, [availableBays, bayId]);
  const networkStatus = bays.some((bay) => ["OFFLINE", "MAINTENANCE"].includes(bay.status)) ? (bays.every((bay) => ["OFFLINE", "MAINTENANCE"].includes(bay.status)) ? "offline" : "degraded") : "online";
  const selectedRobot = robots.find((robot) => robot.id === robotId);
  const canSend = Boolean(robotId && bayId && eligibleRobots.some((robot) => robot.id === robotId) && availableBays.some((bay) => bay.id === bayId));
  return <>
    <PageTitle kicker={`ENERGY MANAGEMENT / ${environment.label.toUpperCase()} · ${environment.warehouse}`} title="Charger Bay" description="Direct energy flow, bay availability, and safe robot recovery across the workspace." action={<span className={`charger-network-status ${networkStatus}`}><span /> Charger network {networkStatus}</span>} />
    <div className="charger-layout">
      <section className="card charger-dispatch-card"><div className="card-heading"><div><span className="eyebrow">MANUAL DISPATCH</span><h3>Send robot to charger</h3><p>Manually choose an available vehicle and bay.</p></div><div className="charger-card-icon"><BatteryCharging size={19} /></div></div>
        <div className="charger-form"><label><span>Robot</span><select value={robotId} onChange={(event) => setRobotId(event.target.value)} disabled={!eligibleRobots.length}><option value="">{eligibleRobots.length ? "Select robot" : "No available robots"}</option>{robots.map((robot) => { const canAssign = eligibleRobots.some((entry) => entry.id === robot.id); return <option key={robot.id} value={robot.id} disabled={!canAssign}>{robot.id} — {canAssign ? "Idle" : statusLabel[robot.status]} — {Math.round(robot.battery)}% battery</option>; })}</select></label>
          <label><span>Charging bay</span><select value={bayId} onChange={(event) => setBayId(event.target.value)} disabled={!availableBays.length}><option value="">{availableBays.length ? "Select bay" : "No charging bays available"}</option>{bays.map((bay) => <option key={bay.id} value={bay.id} disabled={bay.status !== "AVAILABLE"}>{bay.id} · {bay.status.charAt(0) + bay.status.slice(1).toLowerCase()}</option>)}</select></label>
        </div>
        <div className="charger-validation"><span className="live-pip" /> {selectedRobot ? `${selectedRobot.id} ready · ${Math.round(selectedRobot.battery)}% battery` : "Select an eligible robot to continue"}</div>
        <button className="button button-primary charger-send-button" disabled={!canSend} onClick={() => onSendToCharger(robotId, bayId)}><BatteryCharging size={15} /> Send to charger</button>
      </section>
      <section className="charger-plots"><div className="charger-section-heading"><div><span className="eyebrow">CHARGING PLOTS</span><h3>Charging bays</h3></div><strong>{bays.length} bays</strong></div><div className="charger-bay-grid">{bays.map((bay) => <ChargerBayCard bay={bay} robot={bay.robotId ? robots.find((entry) => entry.id === bay.robotId) : undefined} key={bay.id} />)}</div></section>
    </div>
  </>;
}
function ChargerBayCard({ bay, robot }: { bay: ChargerBay; robot?: Robot }) { const label = bay.status === "OCCUPIED" ? "Charging" : bay.status.charAt(0) + bay.status.slice(1).toLowerCase(); return <article className={`card charger-bay-card ${bay.status.toLowerCase()}`}><div className="charger-bay-top"><strong>{bay.id}</strong><span className="charger-status-dot"><i /> {label}</span></div><div className="charger-bay-visual"><BatteryCharging size={30} /><strong>{bay.status === "AVAILABLE" ? "Ready for assignment" : bay.status === "RESERVED" ? "Robot en route" : bay.status === "OCCUPIED" ? `${robot?.id ?? bay.robotId ?? "Robot"} charging` : "Unavailable"}</strong><span>{bay.status === "AVAILABLE" ? "No robot assigned" : bay.lastEvent}</span>{robot && bay.status === "OCCUPIED" && <div className="charger-progress"><i style={{ width: `${Math.min(100, robot.battery)}%` }} /></div>}</div><div className="charger-bay-meta"><span>{bay.output ? `${bay.output.toFixed(1)} kW output` : "Output ready"}</span><span>{robot ? `${Math.round(robot.battery)}%` : bay.status === "AVAILABLE" ? "Ready" : "—"}</span></div></article>; }

function HomeView({ robots, tasks, counts, activity, onNavigate, onCreateTask, environment }: { robots: Robot[]; tasks: Task[]; counts: { active: number; idle: number; charging: number; low: number }; activity: { time: string; message: string; type: string }[]; onNavigate: (path: string) => void; onCreateTask: () => void; environment: EnvironmentConfig }) {
  const averageBattery = Math.round(robots.reduce((sum, robot) => sum + robot.battery, 0) / robots.length);
  return <>
    <PageTitle kicker={`CONTROL CENTER / ${environment.label.toUpperCase()} · ${environment.warehouse}`} title="Keep the floor moving." description={`One connected view of autonomous work across ${environment.label}.`} action={<div className="title-actions"><button className="button button-quiet" onClick={() => onNavigate("/analytics")}><BarChart3 size={15} /> View analytics</button><button className="button button-primary" onClick={onCreateTask}><Plus size={16} /> New task</button></div>} />
    <div className="home-grid">
      <section className="card hero-card">
        <div className="hero-card-top"><div><span className="eyebrow">FLEET PULSE</span><h2>Parallel operations are live</h2><p>All active routes are being scheduled independently by the fleet manager.</p></div><div className="hero-live"><span className="live-pip" /> LIVE</div></div>
        <div className="pulse-grid"><Metric label="Moving" value={`${counts.active}`} detail="robots" tone="orange" icon={<Navigation size={16} />} /><Metric label="Idle / ready" value={`${counts.idle}`} detail="available" tone="slate" icon={<Bot size={16} />} /><Metric label="Charging" value={`${counts.charging}`} detail="bay 01" tone="green" icon={<BatteryCharging size={16} />} /><Metric label="Mean battery" value={`${averageBattery}%`} detail="fleet average" tone="teal" icon={<Zap size={16} />} /></div>
        <div className="mini-route"><div className="mini-route-label"><span>SHIFT THROUGHPUT</span><strong>84 <small>totes / hr</small></strong></div><div className="sparkline"><span /><span /><span /><span /><span /><span /><span /><span /><span /><span /><span /><span /><i /></div><div className="delta positive"><ArrowUpRight size={13} /> 12.4% vs. last shift</div></div>
      </section>
      <section className="card activity-card"><div className="card-heading"><div><span className="eyebrow">ACTIVITY STREAM</span><h3>What’s happening now</h3></div><button className="text-button" onClick={() => onNavigate("/alerts")}>View all <ArrowUpRight size={13} /></button></div><div className="activity-list">{activity.slice(0, 4).map((item, index) => <div className="activity-row" key={`${item.time}-${index}`}><div className={`activity-icon ${item.type}`}>{item.type === "warning" ? <AlertTriangle size={14} /> : item.type === "success" ? <CheckCircle2 size={14} /> : <Activity size={14} />}</div><div><strong>{item.message}</strong><span>{item.time} · {environment.label}</span></div></div>)}</div></section>
      <section className="card map-preview-card"><div className="card-heading"><div><span className="eyebrow">SPATIAL OVERVIEW</span><h3>Live Map</h3></div><button className="icon-button" onClick={() => onNavigate("/live-map")} aria-label="Open live map"><ArrowUpRight size={16} /></button></div><div className="map-preview"><WarehouseMap robots={robots} selectedRobot={null} onSelectRobot={() => {}} compact environment={environment} /></div><div className="map-preview-footer"><span><span className="live-pip" /> {counts.active} routes active</span><button className="text-button" onClick={() => onNavigate("/live-map")}>Open live map <ArrowUpRight size={13} /></button></div></section>
      <section className="card jobs-card"><div className="card-heading"><div><span className="eyebrow">WORK QUEUE</span><h3>Active jobs</h3></div><button className="text-button" onClick={() => onNavigate("/tasks")}>Manage <ArrowUpRight size={13} /></button></div><div className="job-list">{tasks.filter((task) => task.status !== "COMPLETED").slice(0, 4).map((task) => <div className="job-row" key={task.id}><div className={`job-priority ${task.priority.toLowerCase()}`} /><div className="job-main"><div><strong>{task.id}</strong><span>{task.pickup} <ArrowDownLeft size={11} /> {task.destination}</span></div><div className="job-meta"><span>{task.assignedRobot}</span><span>{task.status}</span></div><div className="thin-progress"><i style={{ width: `${task.progress}%` }} /></div></div><span className="job-eta">{task.eta}</span></div>)}</div></section>
    </div>
    <footer className="bottom-status"><span><ShieldCheck size={14} /> Safety reserve enforced</span><span><Route size={14} /> Fixed-path network online</span><span><Radio size={14} /> 5 robots reporting</span><span className="status-foot-right">Last scheduler tick 260ms ago</span></footer>
  </>;
}

function MoreIcon() { return <span className="more-icon">•••</span>; }

function EnvironmentPanel({ current, environments, onSelect }: { current: EnvironmentConfig; environments: EnvironmentConfig[]; onSelect: (environment: EnvironmentConfig) => void }) {
  return <section className="floating-panel environment-panel" role="dialog" aria-label="Select environment"><div className="floating-panel-header"><div><span className="eyebrow">WORKSPACE SELECTOR</span><h3>Choose environment</h3></div><span className="live-pip" /></div>{environments.map((environment) => <button className={`environment-option ${current.id === environment.id ? "active" : ""}`} key={environment.id} onClick={() => onSelect(environment)}><span className="site-dot" /><span><strong>{environment.label} · {environment.warehouse}</strong><small>{environment.description}</small></span><em>{environment.status}</em></button>)}</section>;
}

function SearchPanel({ query, setQuery, robots, tasks, locations, pages, onRobot, onTask, onLocation, onPage }: { query: string; setQuery: (value: string) => void; robots: Robot[]; tasks: Task[]; locations: string[]; pages: { label: string; path: string }[]; onRobot: (id: string) => void; onTask: (id: string) => void; onLocation: (location: string) => void; onPage: (path: string) => void }) {
  const hasResults = robots.length + tasks.length + locations.length + pages.length > 0;
  return <section className="floating-panel search-panel" role="dialog" aria-label="Global search"><div className="search-panel-input"><Search size={16} /><input autoFocus value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search robots, tasks, locations, or pages" /></div>{!query && <p className="panel-hint">Try “FB-01”, “T-1042”, “Storage Zone A”, or “Analytics”.</p>}{query && !hasResults && <EmptyState label="No matching operational records" />}{robots.length > 0 && <SearchGroup label="ROBOTS">{robots.map((robot) => <button key={robot.id} onClick={() => onRobot(robot.id)}><Bot size={13} /><span><strong>{robot.id}</strong><small>{robot.label} · {statusLabel[robot.status]}</small></span></button>)}</SearchGroup>}{tasks.length > 0 && <SearchGroup label="TASKS">{tasks.map((task) => <button key={task.id} onClick={() => onTask(task.id)}><ClipboardList size={13} /><span><strong>{task.id}</strong><small>{task.pickup} → {task.destination}</small></span></button>)}</SearchGroup>}{locations.length > 0 && <SearchGroup label="LOCATIONS">{locations.map((location) => <button key={location} onClick={() => onLocation(location)}><MapPinned size={13} /><span><strong>{location}</strong><small>Open on Live Map</small></span></button>)}</SearchGroup>}{pages.length > 0 && <SearchGroup label="PAGES">{pages.map((page) => <button key={page.path} onClick={() => onPage(page.path)}><ArrowUpRight size={13} /><span><strong>{page.label}</strong><small>Navigate to page</small></span></button>)}</SearchGroup>}</section>;
}

function SearchGroup({ label, children }: { label: string; children: React.ReactNode }) { return <div className="search-group"><span className="eyebrow">{label}</span>{children}</div>; }

function NotificationPanel({ notifications, onRead, onReadAll, onClear }: { notifications: NotificationItem[]; onRead: (id: string) => void; onReadAll: () => void; onClear: () => void }) {
  return <section className="floating-panel notification-panel" role="dialog" aria-label="Notifications"><div className="floating-panel-header"><div><span className="eyebrow">SIGNAL CENTER</span><h3>Notifications</h3></div><div className="panel-actions"><button className="text-button" onClick={onReadAll}>Mark all read</button><button className="text-button" onClick={onClear}>Clear</button></div></div>{notifications.length ? notifications.map((notification) => <button className={`notification-row ${notification.read ? "read" : "unread"}`} key={notification.id} onClick={() => onRead(notification.id)}><span className={`notification-icon ${notification.type}`}><Bell size={13} /></span><span><strong>{notification.message}</strong><small>{notification.timestamp} · Click to mark read</small></span>{!notification.read && <i className="unread-dot" />}</button>) : <EmptyState label="No notifications" />}</section>;
}

function ProfilePanel({ environment, onSettings }: { environment: EnvironmentConfig; onSettings: () => void }) {
  return <section className="floating-panel profile-panel" role="dialog" aria-label="User profile"><div className="profile-panel-header"><div className="topbar-avatar profile-large">JM</div><div><span className="eyebrow">OPERATOR PROFILE</span><h3>Jordan Mills</h3><p>Shift supervisor</p></div></div><div className="profile-detail-list"><Detail label="Employee ID" value="JM-0042" /><Detail label="Email" value="jordan.mills@flowbot.local" /><Detail label="Account status" value="Active" /><Detail label="Assigned site" value={`${environment.label} · ${environment.warehouse}`} /><Detail label="Last login" value="Today · 08:12" /><Detail label="Access level" value="Fleet operations" /></div><div className="profile-panel-actions"><button className="button button-primary" onClick={onSettings}><Settings size={14} /> Account settings</button><button className="button button-quiet" onClick={() => toast("Profile editing is not enabled", { description: "Contact an administrator to update operator details." })}>View profile</button></div></section>;
}

function AddAmrModal({ form, setForm, mode, onClose, onSubmit }: { form: AmrForm; setForm: React.Dispatch<React.SetStateAction<AmrForm>>; mode: "register" | "edit"; onClose: () => void; onSubmit: () => void }) {
  const title = mode === "register" ? "Register AMR" : "Edit AMR";
  return <div className="modal-backdrop" role="presentation" onMouseDown={(event) => { if (event.currentTarget === event.target) onClose(); }}><section className="modal-card" role="dialog" aria-modal="true" aria-labelledby="amr-modal-title"><div className="modal-heading"><div><span className="eyebrow orange-text">FLEET / {mode === "register" ? "REGISTER NEW UNIT" : "UPDATE UNIT"}</span><h2 id="amr-modal-title">{title}</h2><p>{mode === "register" ? "Register a robot into the live fleet. Idle units remain stationary until assigned a task." : "Update identity and operating parameters without interrupting a safe active route."}</p></div><button className="icon-button" onClick={onClose} aria-label="Close AMR form"><X size={16} /></button></div><div className="amr-form-grid"><label><span>AMR name</span><input value={form.name} onChange={(event) => setForm((current) => ({ ...current, name: event.target.value }))} placeholder="Atlas 06" /></label><label><span>AMR ID</span><input value={form.id} onChange={(event) => setForm((current) => ({ ...current, id: event.target.value.toUpperCase() }))} placeholder="FB-06" /></label><label><span>Model</span><input value={form.model} onChange={(event) => setForm((current) => ({ ...current, model: event.target.value }))} placeholder="FlowBot AMR" /></label><label><span>Serial number</span><input value={form.serial} onChange={(event) => setForm((current) => ({ ...current, serial: event.target.value }))} placeholder="FBX-1047" /></label><label><span>{mode === "register" ? "Initial battery" : "Battery configuration"}</span><div className="input-with-suffix"><input type="number" min="1" max="100" value={form.battery} onChange={(event) => setForm((current) => ({ ...current, battery: event.target.value }))} /><b>%</b></div></label><label><span>Maximum speed</span><div className="input-with-suffix"><input type="number" min="0.2" max="3" step="0.1" value={form.speed} onChange={(event) => setForm((current) => ({ ...current, speed: event.target.value }))} /><b>m/s</b></div></label><label><span>Initial status</span><select value={form.status} onChange={(event) => setForm((current) => ({ ...current, status: event.target.value as RobotStatus }))}><option value="IDLE">IDLE</option><option value="CHARGING">CHARGING</option><option value="FAULT">FAULT</option><option value="UNAVAILABLE">UNAVAILABLE</option></select></label><label><span>Starting location</span><select value={form.location} onChange={(event) => setForm((current) => ({ ...current, location: event.target.value }))}>{Object.keys(startingLocations).map((location) => <option value={location} key={location}>{location}</option>)}</select></label></div><div className="modal-footer"><span><ShieldCheck size={14} /> Fleet safety checks active</span><div><button className="button button-quiet" onClick={onClose}>Cancel</button><button className="button button-primary" onClick={onSubmit}>{mode === "register" ? <><Plus size={15} /> Register AMR</> : <><CheckCircle2 size={15} /> Save changes</>}</button></div></div></section></div>;
}

function TaskModal({ form, setForm, editing, robots, isAnalyzingAllocation, onClose, onSubmit, mode, step, setMode, setStep, candidates, setCandidates, batchCount, setBatchCount, batchForms, setBatchForms, allocations, onChooseSingle, onChooseMultiple, onContinueBatch, onValidateSingle, onValidateBatch, onRunAllocation, onConfirmAllocations }: { form: TaskForm; setForm: React.Dispatch<React.SetStateAction<TaskForm>>; editing: boolean; robots: Robot[]; isAnalyzingAllocation: boolean; onClose: () => void; onSubmit: () => void; mode: TaskWizardMode; step: number; setMode: React.Dispatch<React.SetStateAction<TaskWizardMode>>; setStep: React.Dispatch<React.SetStateAction<number>>; candidates: string[]; setCandidates: React.Dispatch<React.SetStateAction<string[]>>; batchCount: number; setBatchCount: React.Dispatch<React.SetStateAction<number>>; batchForms: TaskForm[]; setBatchForms: React.Dispatch<React.SetStateAction<TaskForm[]>>; allocations: AllocationResult[]; onChooseSingle: () => void; onChooseMultiple: () => void; onContinueBatch: () => void; onValidateSingle: () => void; onValidateBatch: () => void; onRunAllocation: () => void; onConfirmAllocations: () => void }) {
  const locations = ["Receiving", "Storage A", "Storage B", "Picking", "Assembly", "Packing", "Shipping"];
  const eligible = robots.filter((robot) => robot.status === "IDLE" && (robot.isReal || robot.battery >= 28));
  const updateSingle = (key: keyof TaskForm, value: string) => setForm((current) => ({ ...current, [key]: value }));
  const updateBatch = (index: number, key: keyof TaskForm, value: string) => setBatchForms((current) => current.map((item, itemIndex) => itemIndex === index ? { ...item, [key]: value } : item));
  const toggleCandidate = (id: string) => setCandidates((current) => mode === "single" ? (current.includes(id) ? [] : [id]) : current.includes(id) ? current.filter((item) => item !== id) : [...current, id]);
  const title = editing ? "Edit task" : mode === "choose" ? "Create Task" : mode === "single" && step === 4 || mode === "multiple" && step === 4 ? "FlowBot AI Task Allocation" : "Create Task";
  const kicker = editing ? "WORK QUEUE / EDIT TASK" : mode === "choose" ? "WORK QUEUE / NEW TASK" : mode === "single" ? `SINGLE TASK / STEP ${step} OF 3` : `MULTIPLE TASKS / STEP ${step} OF 4`;
  return <div className="modal-backdrop" role="presentation" onMouseDown={(event) => { if (event.currentTarget === event.target) onClose(); }}><section className={`modal-card task-wizard-modal ${mode === "multiple" ? "wizard-wide" : ""}`} role="dialog" aria-modal="true" aria-labelledby="task-modal-title"><div className="modal-heading"><div><span className="eyebrow orange-text">{kicker}</span><h2 id="task-modal-title">{title}</h2><p>{editing ? "Update this task without compromising an active route." : mode === "choose" ? "Create one task or a coordinated batch from the live fleet." : mode === "single" && step === 1 ? "Complete the task before selecting candidate robots." : mode === "single" && step === 2 ? "Only eligible registered robots are shown for comparison." : mode === "multiple" && step === 1 ? "Choose how many tasks to create." : mode === "multiple" && step === 2 ? `${batchForms.length} task forms. Review each route before selecting robots.` : mode === "multiple" && step === 3 ? "Choose the candidate pool. Each robot can receive at most one task." : "Deterministic recommendation from live fleet state and the shared warehouse graph."}</p></div><button className="icon-button" onClick={onClose} aria-label="Close task form"><X size={16} /></button></div>{isAnalyzingAllocation ? <div className="allocation-analysis"><span className="eyebrow orange-text">AI ALLOCATION / ANALYZING</span><div className="wizard-divider" /><div className="allocation-analysis-spinner"><Sparkles size={20} /><strong>Analyzing fleet capacity and route fit…</strong><span>Comparing the selected robots against every task for 2 seconds.</span></div></div> : editing ? <div className="amr-form-grid"><label><span>Task ID</span><input value={form.id} readOnly /></label><label><span>Task type</span><select value={form.taskType} onChange={(event) => updateSingle("taskType", event.target.value)}><option>STANDARD TRANSPORT</option><option>PICKUP & DELIVERY</option><option>PRIORITY DELIVERY</option><option>MULTI-STOP</option></select></label><label><span>Source</span><select value={form.pickup} onChange={(event) => updateSingle("pickup", event.target.value)}>{locations.map((location) => <option key={location}>{location}</option>)}</select></label><label><span>Destination</span><select value={form.destination} onChange={(event) => updateSingle("destination", event.target.value)}>{locations.map((location) => <option key={location}>{location}</option>)}</select></label><label><span>Priority</span><select value={form.priority} onChange={(event) => updateSingle("priority", event.target.value)}><option>LOW</option><option>NORMAL</option><option>HIGH</option><option>URGENT</option></select></label><label><span>Robot assignment</span><select value={form.assignment} onChange={(event) => updateSingle("assignment", event.target.value)}><option value="AUTO">Auto assign</option>{eligible.map((robot) => <option value={robot.id} key={robot.id}>{robot.id} · {robot.label}</option>)}</select></label></div> : mode === "choose" ? <div className="task-type-grid"><button className="task-type-card" onClick={onChooseSingle}><span className="task-type-icon orange"><Package size={22} /></span><span className="eyebrow">OPTION 1</span><strong>Single Task</strong><p>Create one transport task, select candidate robots, and review the recommended allocation.</p><span className="task-type-arrow">Select single task <ArrowUpRight size={14} /></span></button><button className="task-type-card" onClick={onChooseMultiple}><span className="task-type-icon teal"><Boxes size={22} /></span><span className="eyebrow">OPTION 2</span><strong>Multiple Tasks</strong><p>Create a batch and allocate one eligible robot per task from a selected candidate pool.</p><span className="task-type-arrow">Select multiple tasks <ArrowUpRight size={14} /></span></button></div> : mode === "single" && step === 1 ? <TaskDetailsForm form={form} update={updateSingle} locations={locations} /> : mode === "multiple" && step === 1 ? <div className="wizard-count-step"><span className="eyebrow">STEP 1 · MULTIPLE TASK DETAILS</span><label><span>Number of tasks</span><input type="number" min="2" max="12" value={batchCount} onChange={(event) => setBatchCount(Number(event.target.value))} /></label><p>FlowBot will generate one independent task form per task. You can add more before reviewing the batch.</p></div> : mode === "multiple" && step === 2 ? <div className="batch-form-list">{batchForms.map((batchForm, index) => <div className="batch-task-card" key={batchForm.id}><div className="batch-task-heading"><span className="eyebrow">TASK {index + 1}</span><strong>{batchForm.id}</strong></div><div className="batch-form-grid"><label><span>Source</span><select value={batchForm.pickup} onChange={(event) => updateBatch(index, "pickup", event.target.value)}>{locations.map((location) => <option key={location}>{location}</option>)}</select></label><label><span>Destination</span><select value={batchForm.destination} onChange={(event) => updateBatch(index, "destination", event.target.value)}>{locations.map((location) => <option key={location}>{location}</option>)}</select></label><label><span>Task details</span><input value={batchForm.details ?? ""} onChange={(event) => updateBatch(index, "details", event.target.value)} placeholder="Optional instructions" /></label><label><span>Priority</span><select value={batchForm.priority} onChange={(event) => updateBatch(index, "priority", event.target.value)}><option>LOW</option><option>NORMAL</option><option>HIGH</option><option>URGENT</option></select></label></div></div>)}<button className="button button-quiet add-batch-button" onClick={() => { const next = batchForms.length; setBatchCount(next + 1); setBatchForms((current) => [...current, { id: `TSK-${String(100 + next + 1).padStart(3, "0")}`, pickup: "Receiving", destination: "Storage A", priority: "NORMAL", taskType: "STANDARD TRANSPORT", assignment: "AUTO", details: "" }]); }}><Plus size={14} /> Add Task</button></div> : (mode === "single" && step === 2) || (mode === "multiple" && step === 3) ? <RobotCandidateStep robots={robots} eligible={eligible} candidates={candidates} toggle={toggleCandidate} multiple={mode === "multiple"} /> : <AllocationReview allocations={allocations} />}{editing ? <div className="modal-footer"><span><Route size={14} /> Battery and path eligibility checked</span><div><button className="button button-quiet" onClick={onClose}>Cancel</button><button className="button button-primary" onClick={onSubmit}><CheckCircle2 size={15} /> Save task</button></div></div> : <div className="modal-footer"><span><Route size={14} /> {isAnalyzingAllocation ? "AI is analyzing selected robots and tasks…" : "Fixed graph · safety reserve enforced"}</span><div>{!isAnalyzingAllocation && mode !== "choose" && step !== 4 && <button className="button button-quiet" onClick={() => setStep((current) => Math.max(mode === "single" ? 1 : 1, current - 1))}>Back</button>}{mode === "choose" ? null : mode === "single" && step === 1 ? <button className="button button-primary" onClick={onValidateSingle}>Next: Select Robots <ArrowUpRight size={14} /></button> : mode === "single" && step === 2 ? <button className="button button-primary" disabled={isAnalyzingAllocation} onClick={onRunAllocation}>{isAnalyzingAllocation ? "Analyzing…" : "Run AI Allocation"} <Sparkles size={14} /></button> : mode === "multiple" && step === 1 ? <button className="button button-primary" onClick={onContinueBatch}>Continue <ArrowUpRight size={14} /></button> : mode === "multiple" && step === 2 ? <button className="button button-primary" onClick={onValidateBatch}>Next: Select Robots <ArrowUpRight size={14} /></button> : mode === "multiple" && step === 3 ? <button className="button button-primary" disabled={isAnalyzingAllocation} onClick={onRunAllocation}>{isAnalyzingAllocation ? "Analyzing…" : "Run AI Allocation"} <Sparkles size={14} /></button> : <><button className="button button-quiet" onClick={() => setStep((mode === "single" ? 2 : 3))}>Back to Robot Selection</button><button className="button button-primary" onClick={onConfirmAllocations}>Confirm & Start {mode === "multiple" ? "Tasks" : "Task"} <CheckCircle2 size={14} /></button></>}</div></div>}</section></div>;
}

function TaskDetailsForm({ form, update, locations }: { form: TaskForm; update: (key: keyof TaskForm, value: string) => void; locations: string[] }) { return <div className="wizard-details"><span className="eyebrow">STEP 1 · TASK DETAILS</span><div className="wizard-divider" /><div className="amr-form-grid"><label><span>Task ID</span><input value={form.id} readOnly /></label><label><span>Source</span><select value={form.pickup} onChange={(event) => update("pickup", event.target.value)}>{locations.map((location) => <option key={location}>{location}</option>)}</select></label><label><span>Destination</span><select value={form.destination} onChange={(event) => update("destination", event.target.value)}>{locations.map((location) => <option key={location}>{location}</option>)}</select></label><label><span>Priority</span><select value={form.priority} onChange={(event) => update("priority", event.target.value)}><option>LOW</option><option>NORMAL</option><option>HIGH</option><option>URGENT</option></select></label><label className="field-span-2"><span>Task details <em>OPTIONAL</em></span><input value={form.details ?? ""} onChange={(event) => update("details", event.target.value)} placeholder="Move materials from Storage Zone A to Packing Area" /></label></div></div>; }

function RobotCandidateStep({ robots, eligible, candidates, toggle, multiple }: { robots: Robot[]; eligible: Robot[]; candidates: string[]; toggle: (id: string) => void; multiple: boolean }) { return <div className="wizard-robots"><span className="eyebrow">STEP {multiple ? "2" : "2"} · SELECT ROBOTS FOR AI ALLOCATION</span><div className="wizard-divider" />{robots.map((robot) => { const allowed = eligible.some((item) => item.id === robot.id); return <button className={`candidate-robot-row ${candidates.includes(robot.id) ? "selected" : ""} ${allowed ? "" : "disabled"}`} key={robot.id} disabled={!allowed} onClick={() => toggle(robot.id)}><span className={`candidate-check ${candidates.includes(robot.id) ? "checked" : ""}`}>{candidates.includes(robot.id) ? "✓" : ""}</span><span className={`roster-robot ${robot.color}`}><Bot size={14} /></span><span className="candidate-main"><strong>{robot.id} · {robot.label}</strong><small>{statusLabel[robot.status]} · {robot.location}</small></span><span className="candidate-availability"><strong>{allowed ? "Available" : "Ineligible"}</strong><small>{Math.round(robot.battery)}% · {allowed ? "safe route candidate" : "busy or below reserve"}</small></span></button>; })}</div>; }

function AllocationMetric({ icon, label, value, detail }: { icon: React.ReactNode; label: string; value: string; detail: string }) { return <div className="allocation-metric"><span className="allocation-metric-icon">{icon}</span><span className="allocation-metric-label">{label}</span><strong className="allocation-metric-value">{value}</strong><small className="allocation-metric-detail">{detail}</small></div>; }

function AllocationReview({ allocations }: { allocations: AllocationResult[] }) { return <div className="allocation-review"><span className="eyebrow">REVIEW ALLOCATION</span><div className="wizard-divider" />{allocations.map((allocation) => <article className={`allocation-card ${allocation.feasible ? "feasible" : "not-feasible"}`} key={allocation.task.id}><div className="allocation-heading"><div className="allocation-route"><span className="eyebrow">TASK {allocation.task.id}</span><strong>{allocation.task.pickup} <span aria-hidden="true">→</span> {allocation.task.destination}</strong></div><span className={`decision-badge ${allocation.feasible ? "good" : "bad"}`}>{allocation.feasible ? "SUITABLE" : "NOT FEASIBLE"}</span></div><div className="allocation-metrics"><AllocationMetric label="Recommended robot" value={allocation.robotId ?? "Unassigned"} detail="one robot, one task" icon={<Bot size={14} />} /><AllocationMetric label="Battery" value={formatDisplayNumber(allocation.battery, "%")} detail="live reading" icon={<BatteryCharging size={14} />} /><AllocationMetric label="Distance" value={formatDisplayNumber(allocation.distance, " m")} detail="fixed route" icon={<Route size={14} />} /><AllocationMetric label="Remaining" value={formatDisplayNumber(allocation.remaining, "%")} detail="after route" icon={<ShieldCheck size={14} />} /></div><p className={allocation.feasible ? "allocation-explanation" : "allocation-explanation danger-text"}>{allocation.explanation}</p></article>)}</div>; }

function PageTitle({ kicker, title, description, action }: { kicker: string; title: string; description: string; action?: React.ReactNode }) { return <div className="page-title-row"><div><div className="eyebrow orange-text">{kicker}</div><h1>{title}</h1><p>{description}</p></div>{action}</div>; }

function LiveMapView({ robots, tasks, selectedRobot, counts, mapZoom, setMapZoom, onSelectRobot, speed, setSpeed, paused, emergency, pauseAll, resumeAll, emergencyStop, stopSelectedRobot, activity, environment, showBattery, showStatus, showRoute, dashboardFontSize }: { robots: Robot[]; tasks: Task[]; selectedRobot: Robot; counts: { active: number; idle: number; charging: number; low: number }; mapZoom: number; setMapZoom: React.Dispatch<React.SetStateAction<number>>; onSelectRobot: (id: string) => void; speed: number; setSpeed: React.Dispatch<React.SetStateAction<number>>; paused: boolean; emergency: boolean; pauseAll: () => void; resumeAll: () => void; emergencyStop: () => void; stopSelectedRobot: () => void; activity: { time: string; message: string; type: string }[]; environment: EnvironmentConfig; showBattery: boolean; showStatus: boolean; showRoute: boolean; dashboardFontSize: number }) {
  return <>
    <PageTitle kicker="LIVE MAP / AUTO REFRESH 260MS" title="Warehouse floor plan" description="Fixed navigation network with independent routes for every active AMR." action={<div className="title-actions"><div className={`map-status ${emergency ? "danger" : paused ? "paused" : ""}`}><span className="status-dot" /> {emergency ? "EMERGENCY STOP" : paused ? "FLEET PAUSED" : "LIVE TRACKING"}</div></div>} />
    <div className="live-layout">
      <section className="card map-card"><div className="map-toolbar"><div className="map-toolbar-left"><span className="eyebrow">{environment.label.toUpperCase()} / {environment.warehouse} · LEVEL 01</span><span className="toolbar-divider" /><span className="map-coordinates">X 0042 · Y 0188</span></div><div className="map-toolbar-actions"><button className="icon-button" aria-label="Locate selected robot"><LocateFixed size={15} /></button><button className="icon-button" onClick={() => setMapZoom((zoom) => Math.min(1.18, zoom + 0.08))} aria-label="Zoom in"><Plus size={15} /></button><button className="icon-button" onClick={() => setMapZoom((zoom) => Math.max(0.88, zoom - 0.08))} aria-label="Zoom out"><Minus size={15} /></button><button className="icon-button" aria-label="Map layers"><LayersIcon /></button></div></div><div className="map-surface"><WarehouseMap robots={robots} selectedRobot={selectedRobot?.id ?? null} onSelectRobot={onSelectRobot} zoom={mapZoom} environment={environment} showBattery={showBattery} showStatus={showStatus} showRoute={showRoute} dashboardFontSize={dashboardFontSize} /></div><div className="map-footer"><div className="map-stats"><span><span className="legend-dot orange" /> {counts.active} moving</span><span><span className="legend-dot green" /> {counts.charging} charging</span><span><span className="legend-dot slate" /> {counts.idle} idle</span><span><span className="legend-dot warn" /> {counts.low} battery watch</span></div><span className="map-note"><ShieldCheck size={13} /> Traffic guard online</span></div></section>
      <aside className="map-side-panel">
	        <section className="card selected-robot-card"><div className="card-heading"><div><span className="eyebrow">SELECTED AMR</span><h3>{selectedRobot.label}</h3></div><span className={`robot-status-chip ${selectedRobot.status.toLowerCase()}`}><span className="status-dot" /> {statusLabel[selectedRobot.status]}</span></div><div className="robot-profile"><div className={`robot-orb ${selectedRobot.color}`}><Bot size={25} /></div><div><strong>{selectedRobot.id}</strong><span>{selectedRobot.location}</span></div><div className="battery-readout"><strong>{Math.round(selectedRobot.battery)}%</strong><span>BATTERY</span></div></div><div className="detail-grid"><Detail label="Current task" value={selectedRobot.taskId ?? "No task"} /><Detail label="Destination" value={selectedRobot.destination} /><Detail label="Route state" value={selectedRobot.lastEvent} /><Detail label="ETA" value={selectedRobot.taskId ? tasks.find((task) => task.id === selectedRobot.taskId)?.eta ?? "—" : "—"} /></div><div className="battery-bar"><div className={`battery-fill ${batteryTone(selectedRobot.battery)}`} style={{ width: `${selectedRobot.battery}%` }} /></div><div className="battery-caption"><span>Battery reserve</span><span>{selectedRobot.battery < 30 ? "Charging required" : "Within safe range"}</span></div>{(selectedRobot.lastTaskMode ?? tasks.find((task) => task.id === selectedRobot.taskId)?.executionMode ?? "single") === "single" && <MovementPlan robot={selectedRobot} />}</section>
        <section className="card fleet-roster-card"><div className="card-heading"><div><span className="eyebrow">FLEET ROSTER</span><h3>Five AMRs reporting</h3></div><button className="icon-button" aria-label="Refresh roster"><RefreshCw size={14} /></button></div><div className="roster-list">{robots.map((robot) => <button className={`roster-row ${selectedRobot.id === robot.id ? "selected" : ""}`} key={robot.id} onClick={() => onSelectRobot(robot.id)}><span className={`roster-robot ${robot.color}`}><Bot size={14} /></span><span className="roster-main"><strong>{robot.id}</strong><span>{robot.destination === "—" ? robot.location : robot.destination}</span></span><span className={`roster-status ${batteryTone(robot.battery)}`}>{Math.round(robot.battery)}%</span><span className={`roster-state ${robot.status.toLowerCase()}`}>{statusLabel[robot.status]}</span></button>)}</div></section>
        <section className="card speed-card"><div className="card-heading"><div><span className="eyebrow">MOTION CONTROL</span><h3>Robot speed</h3></div><Gauge size={17} className="muted-icon" /></div><div className="speed-row"><button className={`speed-pill ${speed === 0.5 ? "active" : ""}`} onClick={() => setSpeed(0.5)}>0.5x</button><button className={`speed-pill ${speed === 1 ? "active" : ""}`} onClick={() => setSpeed(1)}>1x</button><button className={`speed-pill ${speed === 1.5 ? "active" : ""}`} onClick={() => setSpeed(1.5)}>1.5x</button><button className={`speed-pill ${speed === 2 ? "active" : ""}`} onClick={() => setSpeed(2)}>2x</button></div><div className="control-actions"><button className="button button-quiet" onClick={paused ? resumeAll : pauseAll}>{paused ? <Play size={14} /> : <Pause size={14} />}{paused ? "Resume all" : "Pause all"}</button><button className="button button-quiet" onClick={stopSelectedRobot}><Octagon size={14} /> Stop selected</button><button className="button button-stop" onClick={emergencyStop}><Octagon size={14} /> E-stop</button></div></section>
      </aside>
    </div>
    <section className="card map-activity-strip"><div><span className="eyebrow">ROUTE EVENTS</span><strong>Traffic coordination</strong></div><div className="route-event-list">{activity.slice(0, 3).map((item, index) => <span key={index}><i className={`event-pip ${item.type}`} />{item.message}</span>)}</div></section>
  </>;
}

function WarehouseMap({ robots, selectedRobot, onSelectRobot, compact = false, zoom = 1, environment, showBattery = true, showStatus = true, showRoute = true, dashboardFontSize = 100 }: { robots: Robot[]; selectedRobot: string | null; onSelectRobot: (id: string) => void; compact?: boolean; zoom?: number; environment?: EnvironmentConfig; showBattery?: boolean; showStatus?: boolean; showRoute?: boolean; dashboardFontSize?: number }) {
  const mapScale = compact ? 0.94 : zoom;
  return <div className={`warehouse-map-wrap ${compact ? "compact" : ""}`}><svg viewBox="0 0 920 390" preserveAspectRatio="none" className={`warehouse-map-svg ${environment?.mapVariant ?? "north"}`} role="img" aria-label="Live warehouse map showing open storage and assembly zones with fixed navigation paths" style={{ transform: `scale(${mapScale})`, "--live-map-font-scale": dashboardFontSize / 100 } as React.CSSProperties}>
    <defs><pattern id="mapDots" width="20" height="20" patternUnits="userSpaceOnUse"><circle cx="1" cy="1" r="0.8" fill="#c9d2d7" opacity="0.55" /></pattern><filter id="robotShadow" x="-30%" y="-30%" width="160%" height="160%"><feDropShadow dx="0" dy="2" stdDeviation="3" floodColor="#102334" floodOpacity="0.16" /></filter></defs>
    <rect x="0" y="0" width="920" height="390" fill="#f6f8f6" /><rect x="0" y="0" width="920" height="390" fill="url(#mapDots)" opacity="0.35" /><rect className="warehouse-boundary" x="15" y="18" width="890" height="354" rx="3" />
    <text x="48" y="34" className="map-environment-label">{environment ? `${environment.label.toUpperCase()} · ${environment.warehouse}` : "NORTH HUB · WH-04"}</text><g className="map-lane-labels"><text x="44" y="190">CORRIDOR 01</text><text x="385" y="190">C-04</text><text x="574" y="190">C-05</text><text x="46" y="350">CROSS DOCK / SOUTH</text></g>
    <g className="path-network">{warehouseSegments.map((points, index) => <polyline key={`network-${index}`} points={points.map((point) => point.join(",")).join(" ")} className="network-corridor" />)}{Object.entries(routeCatalog).map(([name, points]) => <polyline key={name} points={points.map((point) => point.join(",")).join(" ")} className="route-line" />)}{showRoute && robots.filter((robot) => robot.route.length > 1 && robot.status !== "IDLE").map((robot) => <polyline key={`${robot.id}-active`} points={robot.route.map((point) => point.join(",")).join(" ")} className={`active-route ${robot.color}`} />)}</g>
    <g className="path-nodes">{Object.values(warehouseNodes).map(([x, y], index) => <circle key={index} cx={x} cy={y} r="3" />)}</g>
    {zoneCatalog.map((zone) => <g key={zone.name} className={`zone zone-${zone.accent}`}><rect x={zone.x} y={zone.y} width={zone.w} height={zone.h} rx="3" /><line x1={zone.x + 12} y1={zone.y + 30} x2={zone.x + zone.w - 12} y2={zone.y + 30} className="zone-rule" /><text x={zone.x + 12} y={zone.y + 20} className="zone-code">{zone.code}</text><text x={zone.x + 12} y={zone.y + 61} className="zone-label">{zone.name}</text><text x={zone.x + 12} y={zone.y + 80} className="zone-sub">{zone.name === "CHARGING STATION" ? "4 / 8 BAYS OCCUPIED" : zone.name === "RECEIVING AREA" ? "INBOUND DOCK 01—03" : zone.name === "SHIPPING AREA" ? "OUTBOUND DOCK 04—06" : "OPEN OPERATING ZONE"}</text>{zone.name === "CHARGING STATION" && <><rect x={zone.x + 98} y={zone.y + 48} width="20" height="39" rx="2" className="charge-bay" /><rect x={zone.x + 124} y={zone.y + 48} width="12" height="39" rx="2" className="charge-bay muted" /></>}</g>)}
    <g className="door-marks"><path d="M185 95h12v16h-12M370 95h12v16h-12M550 95h12v16h-12M185 270h12v16h-12M370 270h12v16h-12M550 270h12v16h-12" /></g>
    {robots.map((robot) => { const [x, y] = displayPoint(robot, robots); const isSelected = robot.id === selectedRobot; return <g key={robot.id} className={`map-robot ${isSelected ? "selected" : ""}`} transform={`translate(${x} ${y})`} onClick={() => onSelectRobot(robot.id)} filter="url(#robotShadow)"><circle className="robot-halo" r={isSelected ? 18 : 14} /><rect x="-10" y="-7" width="20" height="14" rx="4" className={`robot-body ${robot.color}`} /><rect x="-5" y="-4" width="10" height="3" rx="1.5" className="robot-screen" /><circle cx="-6" cy="7" r="2" className="robot-wheel" /><circle cx="6" cy="7" r="2" className="robot-wheel" /><text x="14" y="-8" className="robot-id">{robot.id}</text>{isSelected && (showBattery || showStatus) && <><rect x="14" y="-1" width="80" height="24" rx="4" className="robot-tooltip" /><text x="22" y="14" className="robot-tooltip-text">{showBattery ? `${Math.round(robot.battery)}%` : ""}{showBattery && showStatus ? " · " : ""}{showStatus ? statusLabel[robot.status] : ""}</text></>}</g>; })}
    <g className="north-marker"><text x="866" y="348">N</text><path d="M866 354v12M862 358l4-4 4 4" /></g>
  </svg></div>;
}

function FleetView({ robots, tasks, search, setSearch, onSelectRobot, onAddAmr, onEditAmr, onDeleteAmr, fleetFilter, setFleetFilter }: { robots: Robot[]; tasks: Task[]; search: string; setSearch: (value: string) => void; onSelectRobot: (id: string) => void; onAddAmr: () => void; onEditAmr: (robot: Robot) => void; onDeleteAmr: (robot: Robot) => void; fleetFilter: string; setFleetFilter: (value: string) => void }) {
  const visible = robots.filter((robot) => `${robot.id} ${robot.label} ${robot.location} ${robot.status} ${robot.model} ${robot.serial}`.toLowerCase().includes(search.toLowerCase())).filter((robot) => fleetFilter === "ALL" || (fleetFilter === "ACTIVE" ? robot.status.includes("MOVING") : fleetFilter === "IDLE" ? robot.status === "IDLE" : fleetFilter === "CHARGING" ? robot.status === "CHARGING" : fleetFilter === "LOW" ? robot.battery < 20 : fleetFilter === "FAULT" ? robot.status === "FAULT" : robot.status === "UNAVAILABLE"));
  return <><PageTitle kicker="FLEET MANAGEMENT" title="Fleet" description="Register, monitor, and maintain every autonomous unit on the floor." action={<button className="button button-primary" onClick={onAddAmr}><Plus size={16} /> Register AMR</button>} /><div className="fleet-summary-row"><Metric label="Total AMRs" value={`${robots.length}`} detail="registered units" tone="slate" icon={<Bot size={16} />} /><Metric label="Active" value={`${robots.filter((robot) => robot.status.includes("MOVING")).length}`} detail="on task" tone="orange" icon={<Activity size={16} />} /><Metric label="Idle" value={`${robots.filter((robot) => robot.status === "IDLE").length}`} detail="awaiting work" tone="teal" icon={<Clock3 size={16} />} /><Metric label="Charging" value={`${robots.filter((robot) => robot.status === "CHARGING").length}`} detail="at or en route" tone="green" icon={<BatteryCharging size={16} />} /></div><section className="card fleet-table-card"><div className="section-card-heading"><div><span className="eyebrow">FLEET REGISTER</span><h3>Registered vehicles <small>{robots.length} total</small></h3></div><select className="table-filter" value={fleetFilter} onChange={(event) => setFleetFilter(event.target.value)}><option value="ALL">All status</option><option value="ACTIVE">Active</option><option value="IDLE">Idle</option><option value="CHARGING">Charging</option><option value="LOW">Low battery</option><option value="FAULT">Fault</option><option value="UNAVAILABLE">Unavailable</option></select></div><div className="toolbar-row compact-toolbar"><div className="search-field"><Search size={15} /><input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search robot, model, serial, or state" /></div></div><div className="table-head fleet-expanded-head"><span>AMR</span><span>MODEL / SERIAL</span><span>BATTERY</span><span>SPEED</span><span>STATUS</span><span>ACTIONS</span></div>{visible.map((robot) => <div className="table-row fleet-data-row fleet-expanded-row" key={robot.id}><button className="robot-cell fleet-row-button" onClick={() => onSelectRobot(robot.id)}><span className={`roster-robot ${robot.color}`}><Bot size={14} /></span><span><strong>{robot.id}</strong><small>{robot.label}</small></span></button><span className="model-cell"><strong>{robot.model}</strong><small>{robot.serial}</small></span><span className={`battery-cell ${batteryTone(robot.battery)}`}><strong>{Math.round(robot.battery)}%</strong><span className="battery-mini"><i style={{ width: `${robot.battery}%` }} /></span></span><span className="speed-cell">{robot.status.includes("MOVING") ? `${robot.speed.toFixed(1)} m/s` : "0 m/s"}</span><span><span className={`status-pill ${robot.status.toLowerCase()}`}><i />{statusLabel[robot.status]}</span></span><span className="row-actions"><button className="icon-button" onClick={() => onEditAmr(robot)} aria-label={`Edit ${robot.id}`}><Settings size={14} /></button><button className="icon-button delete-icon" onClick={() => onDeleteAmr(robot)} aria-label={`Delete ${robot.id}`}><Trash2 size={14} /></button></span></div>)}</section><div className="fleet-footnote"><ShieldCheck size={14} /> Battery-aware scheduler checks route completion and charge access before every assignment. <span>Tasks connected: {tasks.length}</span></div></>;
}

function TasksView({ tasks, search, setSearch, onCreateTask, onDeleteTask, onEditTask, onAllocate, taskFilter, setTaskFilter }: { tasks: Task[]; search: string; setSearch: (value: string) => void; onCreateTask: () => void; onDeleteTask: (task: Task) => void; onEditTask: (task: Task) => void; onAllocate: () => void; taskFilter: string; setTaskFilter: (value: string) => void }) {
  const total = tasks.length; const pending = tasks.filter((task) => task.status === "PENDING").length; const progress = tasks.filter((task) => task.status === "IN PROGRESS").length; const completed = tasks.filter((task) => task.status === "COMPLETED").length;
  return <><PageTitle kicker="WORK QUEUE" title="Tasks" description="Create, allocate, and monitor work orders without losing fleet context." action={<div className="title-actions"><button className="button button-quiet" onClick={onAllocate}><Zap size={15} /> Allocate pending</button><button className="button button-primary" onClick={onCreateTask}><Plus size={16} /> Create task</button></div>} /><div className="task-summary-row"><Metric label="Total tasks" value={`${total}`} detail="in lifecycle" tone="slate" icon={<ClipboardList size={16} />} /><Metric label="Pending" value={`${pending}`} detail="awaiting assignment" tone="amber" icon={<Clock3 size={16} />} /><Metric label="In progress" value={`${progress}`} detail="parallel jobs" tone="orange" icon={<Activity size={16} />} /><Metric label="Completed" value={`${completed}`} detail="successful deliveries" tone="green" icon={<CheckCircle2 size={16} />} /></div><section className="card task-table-card"><div className="section-card-heading"><div><span className="eyebrow">QUEUE MONITOR</span><h3>Task queue <small>{total} total</small></h3></div><div className="filter-pills"><button className={taskFilter === "ALL" ? "active" : ""} onClick={() => setTaskFilter("ALL")}>All</button><button className={taskFilter === "SINGLE" ? "active" : ""} onClick={() => setTaskFilter("SINGLE")}>Single task</button><button className={taskFilter === "MULTI" ? "active" : ""} onClick={() => setTaskFilter("MULTI")}>Multiple tasks</button></div></div><div className="toolbar-row compact-toolbar"><div className="search-field"><Search size={15} /><input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search task ID, source, destination, or robot" /></div></div><div className="table-head task-head expanded-task-head"><span>TASK ID</span><span>SOURCE</span><span>DESTINATION</span><span>ROBOT</span><span>PRIORITY</span><span>STATUS</span><span>ACTIONS</span></div>{tasks.map((task) => <div className="table-row task-row expanded-task-row" key={task.id}><span><strong>{task.id}</strong><small>{task.taskType}</small></span><span>{task.pickup}</span><span>{task.destination}</span><span className="owner-cell"><span className="tiny-robot"><Bot size={12} /></span>{task.assignedRobot === "—" ? "Unassigned" : task.assignedRobot}<small>{task.assignedRobot === "—" ? "Auto assign eligible" : "Selected by battery and route"}</small></span><span><span className={`priority-label ${task.priority.toLowerCase()}`}><i />{task.priority}</span></span><span className={`status-pill ${task.status.toLowerCase().replaceAll(" ", "-")}`}><i />{task.status === "IN PROGRESS" ? "NAVIGATING" : task.status}</span><span className="row-actions"><button className="icon-button" onClick={() => onEditTask(task)} aria-label={`Edit ${task.id}`}><Settings size={14} /></button><button className="icon-button delete-icon" onClick={() => onDeleteTask(task)} aria-label={`Delete ${task.id}`}><Trash2 size={14} /></button></span></div>)}</section></>;
}

function AlertsView({ robots, activity, onNavigate, environment }: { robots: Robot[]; activity: { time: string; message: string; type: string }[]; onNavigate: (path: string) => void; environment: EnvironmentConfig }) { const lowRobots = robots.filter((robot) => robot.battery < 40); return <><PageTitle kicker="ALERTS / OPERATOR ATTENTION" title="Signal center" description="Safety, battery, route, and system events requiring awareness." action={<button className="button button-quiet" onClick={() => onNavigate("/live-map")}><MapPinned size={15} /> Inspect live map</button>} /><div className="alert-overview"><div className="alert-overview-card alert-overview-warning"><AlertTriangle size={18} /><div><strong>{lowRobots.length} battery watch {lowRobots.length === 1 ? "item" : "items"}</strong><span>Reserve checks are active</span></div></div><div className="alert-overview-card"><ShieldCheck size={18} /><div><strong>All routes protected</strong><span>No collision holds detected</span></div></div><div className="alert-overview-card"><Wifi size={18} /><div><strong>Fleet link stable</strong><span>Last heartbeat 32ms ago</span></div></div></div><div className="alerts-grid"><section className="card alerts-list-card"><div className="card-heading"><div><span className="eyebrow">OPEN SIGNALS</span><h3>Needs attention</h3></div><span className="count-badge">{lowRobots.length}</span></div>{lowRobots.length ? lowRobots.map((robot) => <div className="alert-row" key={robot.id}><div className="alert-icon warning"><BatteryCharging size={15} /></div><div><strong>{robot.id} battery watch</strong><span>{Math.round(robot.battery)}% remaining · {robot.lastEvent}</span></div><button className="text-button" onClick={() => onNavigate("/live-map")}>Track <ArrowUpRight size={13} /></button></div>) : <EmptyState label="No active battery alerts" />}</section><section className="card alerts-list-card"><div className="card-heading"><div><span className="eyebrow">EVENT LOG</span><h3>Recent events</h3></div><button className="icon-button"><RefreshCw size={14} /></button></div>{activity.map((item, index) => <div className="alert-row compact-row" key={index}><div className={`alert-icon ${item.type}`}><Activity size={15} /></div><div><strong>{item.message}</strong><span>{item.time} · {environment.label}</span></div></div>)}</section></div></> }

function AnalyticsView({ robots, tasks, environment }: { robots: Robot[]; tasks: Task[]; environment: EnvironmentConfig }) { const avg = robots.length ? Math.round(robots.reduce((sum, robot) => sum + robot.battery, 0) / robots.length) : 0; const completed = tasks.filter((task) => task.status === "COMPLETED").length; const completion = tasks.length ? Math.round((completed / tasks.length) * 100) : 0; const moving = robots.filter((robot) => robot.status.includes("MOVING")).length; return <><PageTitle kicker={`ANALYTICS / ${environment.label.toUpperCase()} · ${environment.warehouse}`} title="Operational signal" description={`Performance patterns from the current workspace: ${environment.description}.`} /><div className="analytics-grid analytics-grid-balanced"><section className="card chart-card"><div className="card-heading"><div><span className="eyebrow">THROUGHPUT</span><h3>Completed totes</h3></div><div className="chart-total"><strong>{environment.throughput.toLocaleString()}</strong><span className="delta positive"><ArrowUpRight size={12} /> 12.4%</span></div></div><div className="bar-chart">{[36, 46, 42, 58, 52, 64, 70, 63, 76, 72, 84, 90].map((height, index) => <div className="bar-column" key={index}><i style={{ height: `${height}%` }} /><span>{String(index + 8).padStart(2, "0")}</span></div>)}</div></section><section className="card kpi-card"><span className="eyebrow">FLEET UTILIZATION</span><div className="kpi-dial"><div><strong>{robots.length ? Math.round((moving / robots.length) * 100) : 0}%</strong><span>ON TASK</span></div></div><div className="kpi-foot"><span><i className="green-dot" /> Live workspace</span><strong>{environment.status}</strong></div></section><section className="card metric-table-card analytics-indicators-card"><div className="card-heading"><div><span className="eyebrow">HEALTH INDEX</span><h3>Fleet indicators</h3></div><Activity size={16} className="muted-icon" /></div><div className="indicator-row"><span>Mean battery</span><strong>{avg}%</strong><div className="indicator-meter"><i style={{ width: `${avg}%` }} /></div></div><div className="indicator-row"><span>Task completion</span><strong>{completion}%</strong><div className="indicator-meter"><i style={{ width: `${completion}%` }} /></div></div><div className="indicator-row"><span>Route safety</span><strong>99.7%</strong><div className="indicator-meter"><i style={{ width: "99.7%" }} /></div></div><div className="indicator-row"><span>Jobs in queue</span><strong>{tasks.filter((task) => task.status !== "COMPLETED").length}</strong><div className="indicator-meter amber"><i style={{ width: `${Math.min(100, tasks.filter((task) => task.status !== "COMPLETED").length * 14)}%` }} /></div></div></section></div></> }

function SettingsView({ speed, setSpeed, settings, setSettings, onReset, onClearCompleted }: { speed: number; setSpeed: React.Dispatch<React.SetStateAction<number>>; settings: SettingsConfig; setSettings: React.Dispatch<React.SetStateAction<SettingsConfig>>; onReset: () => void; onClearCompleted: () => void }) {
  const update = <K extends keyof SettingsConfig>(key: K, value: SettingsConfig[K]) => setSettings((current) => ({ ...current, [key]: value }));
  const Toggle = ({ label, value, onChange }: { label: string; value: boolean; onChange: (value: boolean) => void }) => <div className="setting-row"><div><strong>{label}</strong><span>{value ? "Enabled" : "Disabled"}</span></div><button className={`toggle ${value ? "on" : ""}`} onClick={() => onChange(!value)} aria-label={`Toggle ${label}`}><i /></button></div>;
  return <><PageTitle kicker="SYSTEM CONFIGURATION" title="Settings" description="Tune fleet, battery, routing, and automation behavior for North Hub." action={<div className="setting-live"><span className="live-pip" /> Changes apply on save</div>} /><div className="settings-sections"><section className="card settings-form"><div className="card-heading"><div><span className="eyebrow">FLEET SETTINGS</span><h3>Fleet Configuration</h3></div></div><div className="setting-row"><div><strong>Default robot speed</strong><span>Configured movement speed for active units.</span></div><div className="setting-inline"><input type="number" min="0.2" max="3" step="0.1" value={settings.defaultSpeed} onChange={(event) => update("defaultSpeed", Number(event.target.value))} /><span>m/s</span></div></div><div className="setting-row"><div><strong>Maximum fleet size</strong><span>Registration guardrail for this site.</span></div><div className="setting-inline"><input type="number" min="1" max="100" value={settings.maxFleetSize} onChange={(event) => update("maxFleetSize", Number(event.target.value))} /><span>AMRs</span></div></div><Toggle label="Auto task assignment" value={settings.autoAssign} onChange={(value) => update("autoAssign", value)} /><Toggle label="Parallel operation" value={settings.parallel} onChange={(value) => update("parallel", value)} /></section><section className="card settings-form"><div className="card-heading"><div><span className="eyebrow">BATTERY SETTINGS</span><h3>Battery & Charging</h3></div></div><div className="setting-row"><div><strong>Low battery threshold</strong><span>Alert and protect work below this level.</span></div><div className="setting-inline"><input type="number" min="1" max="50" value={settings.lowBattery} onChange={(event) => update("lowBattery", Number(event.target.value))} /><span>%</span></div></div><div className="setting-row"><div><strong>Critical battery threshold</strong><span>Stop new assignments below this level.</span></div><div className="setting-inline"><input type="number" min="1" max="30" value={settings.criticalBattery} onChange={(event) => update("criticalBattery", Number(event.target.value))} /><span>%</span></div></div><div className="setting-row"><div><strong>Charging completion level</strong><span>Return robots to available at this level.</span></div><div className="setting-inline"><input type="number" min="50" max="100" value={settings.chargeComplete} onChange={(event) => update("chargeComplete", Number(event.target.value))} /><span>%</span></div></div><Toggle label="Automatic charging" value={settings.autoCharge} onChange={(value) => update("autoCharge", value)} /></section><section className="card settings-form"><div className="card-heading"><div><span className="eyebrow">TASK & ROUTING</span><h3>Task Management</h3></div></div><div className="setting-row"><div><strong>Default task priority</strong><span>Applied to new work orders.</span></div><select className="table-filter" value={settings.defaultPriority} onChange={(event) => update("defaultPriority", event.target.value as Task["priority"])}><option>LOW</option><option>NORMAL</option><option>HIGH</option><option>URGENT</option></select></div><Toggle label="Automatic task reassignment" value={settings.autoReassign} onChange={(value) => update("autoReassign", value)} /><div className="setting-row"><div><strong>Reassignment timeout</strong><span>Seconds before interrupted work is reconsidered.</span></div><div className="setting-inline"><input type="number" min="5" max="300" value={settings.reassignmentTimeout} onChange={(event) => update("reassignmentTimeout", Number(event.target.value))} /><span>sec</span></div></div><Toggle label="Follow defined path network" value={settings.followPaths} onChange={(value) => update("followPaths", value)} /><Toggle label="Path intersection coordination" value={settings.coordinateIntersections} onChange={(value) => update("coordinateIntersections", value)} /><Toggle label="Collision avoidance" value={settings.collisionAvoidance} onChange={(value) => update("collisionAvoidance", value)} /></section><section className="card settings-form"><div className="card-heading"><div><span className="eyebrow">LIVE MAP</span><h3>Map presentation</h3></div></div><Toggle label="Real-time robot movement" value={settings.realtime} onChange={(value) => update("realtime", value)} /><Toggle label="Show robot battery" value={settings.showBattery} onChange={(value) => update("showBattery", value)} /><Toggle label="Show robot status" value={settings.showStatus} onChange={(value) => update("showStatus", value)} /><Toggle label="Show assigned route" value={settings.showRoute} onChange={(value) => update("showRoute", value)} /><div className="setting-row"><div><strong>Real robot staging area</strong><span>Used until GET /position returns a valid map-mapped pose.</span></div><select className="table-filter" value={settings.realRobotStagingArea} onChange={(event) => update("realRobotStagingArea", event.target.value)}>{Object.keys(startingLocations).map((location) => <option key={location}>{location}</option>)}</select></div><div className="setting-row"><div><strong>Dashboard font size</strong><span>Scale dashboard typography independently from map fit and zoom.</span></div><div className="speed-row"><button aria-label="Decrease Dashboard font size" onClick={() => update("dashboardFontSize", Math.max(75, settings.dashboardFontSize - 5))}><Minus size={13} /></button><span className="setting-value">{settings.dashboardFontSize}%</span><button aria-label="Increase Dashboard font size" onClick={() => update("dashboardFontSize", Math.min(150, settings.dashboardFontSize + 5))}><Plus size={13} /></button></div></div><div className="setting-row"><div><strong>Animation speed</strong><span>Demo motion speed, separate from robot speed.</span></div><div className="speed-row"><button className={settings.animationSpeed === "SLOW" ? "active" : ""} onClick={() => update("animationSpeed", "SLOW")}>Slow</button><button className={settings.animationSpeed === "NORMAL" ? "active" : ""} onClick={() => update("animationSpeed", "NORMAL")}>Normal</button><button className={settings.animationSpeed === "FAST" ? "active" : ""} onClick={() => update("animationSpeed", "FAST")}>Fast</button></div></div></section><section className="card settings-form destructive-settings"><div className="card-heading"><div><span className="eyebrow">SYSTEM ACTIONS</span><h3>Simulation controls</h3></div></div><div className="setting-row"><div><strong>Reset simulation</strong><span>Stop movement and clear temporary simulation states.</span></div><button className="button button-quiet danger-button" onClick={onReset}>Reset simulation</button></div><div className="setting-row"><div><strong>Clear completed tasks</strong><span>Active and pending tasks will remain untouched.</span></div><button className="button button-quiet" onClick={onClearCompleted}>Clear completed</button></div></section><div className="settings-savebar"><button className="button button-quiet">Cancel</button><button className="button button-primary" onClick={() => toast.success("Settings saved", { description: "Fleet, battery, routing, and map preferences are now active." })}><CheckCircle2 size={15} /> Save Changes</button></div></div></>;
}

function Metric({ label, value, detail, tone, icon }: { label: string; value: string; detail: string; tone: string; icon: React.ReactNode }) { return <div className="metric"><div className={`metric-icon ${tone}`}>{icon}</div><div><span>{label}</span><strong>{value}</strong><small>{detail}</small></div></div>; }
function Detail({ label, value }: { label: string; value: string }) { return <div className="detail"><span>{label}</span><strong>{value}</strong></div>; }
function MovementPlan({ robot }: { robot: Robot }) {
  const commands = extractMovementCommands(robot.route, robot.route.length > 1 ? (robot.routeIndex + robot.segmentProgress) / robot.route.length : 0);
  return <div className="movement-plan"><div className="movement-plan-heading"><div><span className="eyebrow">MOVEMENT PLAN</span><strong>{robot.taskId ? "Prepared from simulation route" : "No active route"}</strong></div><span className="movement-plan-connection"><i />{robot.taskId ? "READY" : "IDLE"}</span></div><div className="movement-plan-steps">{commands.map((command) => <div className={`movement-step ${command.status.toLowerCase()}`} key={`${robot.id}-${command.step}`}><span className="movement-step-state">{command.status === "COMPLETED" ? "✓" : command.status === "EXECUTING" ? "▶" : "○"}</span><span className="movement-step-label">Step {command.step} · {movementActionLabel(command.action)}</span><span className="movement-step-symbol" aria-hidden="true">{movementActionSymbol(command.action)}</span></div>)}</div></div>; }
function EmptyState({ label }: { label: string }) { return <div className="empty-state"><CheckCircle2 size={17} /><span>{label}</span></div>; }
function LayersIcon() { return <span className="layers-glyph"><i /><i /><i /></span>; }
