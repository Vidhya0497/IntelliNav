export type RobotHandshake = {
  robot_id: string;
  status: string;
  robot_type: string;
  api_version: string;
};

export type RobotStatusResponse = {
  robot_id: string;
  status: string;
  current_task: string | null;
  x: number;
  y: number;
};

export type RobotBatteryResponse = {
  robot_id: string;
  battery: number;
};

export type RobotDistanceResponse = {
  robot_id: string;
  distance_to_target: number;
  unit: string;
};

export type RobotPositionResponse = {
  x: number;
  y: number;
  yaw: number;
  frame_id: string;
};

export type NavigationTask = {
  task_id: string;
  destination: string;
  x: number;
  y: number;
  yaw: number;
};

export type NavigationResponse = {
  success: boolean;
  status: string;
  message?: string;
};

export type TimedMoveCommand = {
  linear_x: number;
  angular_z: number;
  duration: number;
  task_id?: string;
  destination?: string;
};

type ApiErrorPayload = { error?: unknown; message?: unknown };

const DEFAULT_TIMEOUT_MS = 5_000;

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null;
}

function requiredString(value: unknown, field: string): string {
  if (typeof value !== "string" || value.trim() === "") {
    throw new Error(`Robot API returned an invalid ${field}.`);
  }
  return value;
}

function finiteNumber(value: unknown, field: string): number {
  if (typeof value !== "number" || !Number.isFinite(value)) {
    throw new Error(`Robot API returned an invalid ${field}.`);
  }
  return value;
}

function parseHandshake(value: unknown): RobotHandshake {
  if (!isRecord(value)) throw new Error("Robot API returned an invalid handshake response.");
  return {
    robot_id: requiredString(value.robot_id, "robot ID"),
    status: requiredString(value.status, "handshake status"),
    robot_type: requiredString(value.robot_type, "robot type"),
    api_version: requiredString(value.api_version, "API version"),
  };
}

function parseStatus(value: unknown): RobotStatusResponse {
  if (!isRecord(value)) throw new Error("Robot API returned an invalid status response.");
  const currentTask = value.current_task;
  if (currentTask !== null && typeof currentTask !== "string") {
    throw new Error("Robot API returned an invalid current task.");
  }
  return {
    robot_id: requiredString(value.robot_id, "robot ID"),
    status: requiredString(value.status, "robot status"),
    current_task: currentTask,
    x: finiteNumber(value.x, "X position"),
    y: finiteNumber(value.y, "Y position"),
  };
}

function parseBattery(value: unknown): RobotBatteryResponse {
  if (!isRecord(value)) throw new Error("Robot API returned an invalid battery response.");
  const battery = finiteNumber(value.battery, "battery");
  if (battery < 0 || battery > 100) throw new Error("Robot API returned a battery outside 0–100%.");
  return { robot_id: requiredString(value.robot_id, "robot ID"), battery };
}

function parseDistance(value: unknown): RobotDistanceResponse {
  if (!isRecord(value)) throw new Error("Robot API returned an invalid distance response.");
  const distance = finiteNumber(value.distance_to_target, "distance to target");
  if (distance < 0) throw new Error("Robot API returned a negative distance to target.");
  return {
    robot_id: requiredString(value.robot_id, "robot ID"),
    distance_to_target: distance,
    unit: requiredString(value.unit, "distance unit"),
  };
}

function parsePosition(value: unknown): RobotPositionResponse {
  if (!isRecord(value)) throw new Error("Robot API returned an invalid position response.");
  return {
    x: finiteNumber(value.x, "X position"),
    y: finiteNumber(value.y, "Y position"),
    yaw: finiteNumber(value.yaw, "yaw"),
    frame_id: requiredString(value.frame_id, "position frame"),
  };
}

function parseNavigationResponse(value: unknown): NavigationResponse {
  if (!isRecord(value)) throw new Error("Robot API returned an invalid navigation response.");
  if (typeof value.success !== "boolean") throw new Error("Robot API returned an invalid navigation result.");
  return {
    success: value.success,
    status: requiredString(value.status, "navigation status"),
    message: typeof value.message === "string" ? value.message : undefined,
  };
}

export class RobotApi {
  private readonly baseUrl: string;

  constructor(ip: string, port: number) {
    const host = ip.trim();
    if (!host) throw new Error("Enter a robot IP address.");
    if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error("Enter a valid API port.");
    this.baseUrl = `http://${host}:${port}`;
  }

  private async get(path: string): Promise<unknown> {
    const controller = new AbortController();
    const timeout = window.setTimeout(() => controller.abort(), DEFAULT_TIMEOUT_MS);
    try {
      const response = await fetch(`${this.baseUrl}${path}`, {
        method: "GET",
        headers: { Accept: "application/json" },
        cache: "no-store",
        signal: controller.signal,
      });
      let payload: unknown = null;
      try {
        payload = await response.json();
      } catch {
        payload = null;
      }
      if (!response.ok) {
        const details = isRecord(payload) ? (payload as ApiErrorPayload) : {};
        const reason = typeof details.error === "string" ? details.error : typeof details.message === "string" ? details.message : `HTTP ${response.status}`;
        throw new Error(`Robot API request failed: ${reason}`);
      }
      return payload;
    } catch (error) {
      if (error instanceof DOMException && error.name === "AbortError") {
        throw new Error("Robot API request timed out.");
      }
      if (error instanceof TypeError) {
        throw new Error("Robot API is unreachable. Check the address, port, network, and CORS settings.");
      }
      throw error;
    } finally {
      window.clearTimeout(timeout);
    }
  }

  private async post(path: string, body?: unknown): Promise<unknown> {
    const controller = new AbortController();
    const timeout = window.setTimeout(() => controller.abort(), DEFAULT_TIMEOUT_MS);
    try {
      const response = await fetch(`${this.baseUrl}${path}`, {
        method: "POST",
        headers: { Accept: "application/json", "Content-Type": "application/json" },
        cache: "no-store",
        body: body === undefined ? undefined : JSON.stringify(body),
        signal: controller.signal,
      });
      let payload: unknown = null;
      try {
        payload = await response.json();
      } catch {
        payload = null;
      }
      if (!response.ok) {
        const details = isRecord(payload) ? (payload as ApiErrorPayload) : {};
        const reason = typeof details.error === "string" ? details.error : typeof details.message === "string" ? details.message : `HTTP ${response.status}`;
        throw new Error(`Robot API request failed: ${reason}`);
      }
      return payload;
    } catch (error) {
      if (error instanceof DOMException && error.name === "AbortError") {
        throw new Error("Robot API request timed out.");
      }
      if (error instanceof TypeError) {
        throw new Error("Robot API is unreachable. Check the address, port, network, and CORS settings.");
      }
      throw error;
    } finally {
      window.clearTimeout(timeout);
    }
  }

  async connectRobot(): Promise<RobotHandshake> {
    return parseHandshake(await this.get("/handshake"));
  }

  async getStatus(): Promise<RobotStatusResponse> {
    return parseStatus(await this.get("/status"));
  }

  async getBattery(): Promise<RobotBatteryResponse> {
    return parseBattery(await this.get("/battery"));
  }

  async getDistanceToTarget(): Promise<RobotDistanceResponse> {
    return parseDistance(await this.get("/distance-to-target"));
  }

  async getPosition(): Promise<RobotPositionResponse> {
    return parsePosition(await this.get("/position"));
  }

  async navigate(task: NavigationTask): Promise<NavigationResponse> {
    if (!task.task_id.trim() || !task.destination.trim()) throw new Error("Navigation task ID and destination are required.");
    if (![task.x, task.y, task.yaw].every(Number.isFinite)) throw new Error("Navigation coordinates must be finite numbers.");
    return parseNavigationResponse(await this.post("/navigate", task));
  }

  async move(command: TimedMoveCommand): Promise<NavigationResponse> {
    if (![command.linear_x, command.angular_z, command.duration].every(Number.isFinite) || command.duration <= 0) {
      throw new Error("Timed movement values must be finite and duration must be positive.");
    }
    return parseNavigationResponse(await this.post("/move", command));
  }

  async stopRobot(): Promise<NavigationResponse> {
    return parseNavigationResponse(await this.post("/stop"));
  }

  async cancelTask(): Promise<NavigationResponse> {
    return parseNavigationResponse(await this.post("/cancel-task"));
  }
}

export function formatRobotApiError(error: unknown): string {
  if (error instanceof Error && error.message) return error.message;
  return "Unexpected robot API error. Check the endpoint and try again.";
}
